# Radar de Prospecção — MVP

## Objetivo
Evoluir “Clientes e leads” sem remover o CRM atual, criando um fluxo funcional de pesquisa real, diagnóstico e conversão em lead.

## Implementação
1. **Nova área Radar**
   - Adicionar “Radar de Prospecção” ao menu, mantendo “Clientes e leads”.
   - Formulário com cidade, estado, segmento, palavra-chave e quantidade.
   - Pesquisa executada somente ao clicar, usando Google Places (fonte autorizada).

2. **Pesquisa real e econômica**
   - Fazer Text Search no servidor com autenticação do representante.
   - Solicitar somente nome, categoria, endereço, telefone, site, localização e link do Google Maps.
   - Limitar resultados por pesquisa e registrar consumo no banco.
   - Exibir falhas da fonte sem quebrar a tela e sem inventar empresas.

3. **Resultados e qualificação**
   - Cards responsivos com dados encontrados e “não identificado na pesquisa” para ausências.
   - Filtro de oportunidade digital.
   - Detalhes da empresa com fonte, data e indicadores de presença digital.
   - Diagnóstico simples baseado somente nos campos retornados.

4. **Conversão e continuidade comercial**
   - “Adicionar ao CRM” copia os dados permitidos, registra origem/diagnóstico/data e cria histórico.
   - Deduplicação pelo identificador da empresa na fonte.
   - “Criar proposta” leva ao gerador com o cliente pré-selecionado.
   - Links externos aparecem somente quando a fonte retorná-los.

5. **Limites e painel**
   - Usar os limites configuráveis por plano já preparados no banco.
   - Mostrar uso mensal no Radar.
   - Adicionar ao painel um resumo do Radar e acesso rápido.

6. **Validação**
   - Corrigir o erro de URL inválida na origem (sem `fetch` com URL vazia ou relativa no servidor).
   - Testar pesquisa, detalhes, filtro, conversão em CRM e abertura da proposta.
   - Conferir visual em desktop e celular.

## Adiado para economizar créditos
- Enriquecimento automático do site oficial para e-mail e redes sociais.
- Criador de sites e automações de contato.
- Métricas avançadas e painel administrativo completo de erros/consumo.
