import { useState, type ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Users,
  Search,
  Package,
  FileText,
  FolderKanban,
  Wallet,
  Shield,
  Rocket,
  LogOut,
  Menu,
} from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/painel", label: "Dashboard", icon: LayoutDashboard },
  { to: "/radar", label: "Radar de Prospecção", icon: Search },
  { to: "/clientes", label: "Clientes e leads", icon: Users },
  { to: "/servicos", label: "Serviços", icon: Package },
  { to: "/propostas", label: "Propostas", icon: FileText },
  { to: "/projetos", label: "Projetos", icon: FolderKanban },
  { to: "/financeiro", label: "Financeiro", icon: Wallet },
] as const;

export function AppShell({
  children,
  isAdmin,
  userName,
}: {
  children: ReactNode;
  isAdmin?: boolean;
  userName?: string;
}) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  const nav = (
    <nav className="space-y-1">
      {NAV.map((item) => (
        <Link
          key={item.to}
          to={item.to}
          onClick={() => setOpen(false)}
          className={cn(
            "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
            pathname === item.to
              ? "bg-primary text-primary-foreground"
              : "text-muted-foreground hover:bg-secondary hover:text-foreground",
          )}
        >
          <item.icon className="size-4" />
          {item.label}
        </Link>
      ))}
      {isAdmin && (
        <Link
          to="/admin"
          onClick={() => setOpen(false)}
          className={cn(
            "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
            pathname === "/admin"
              ? "bg-primary text-primary-foreground"
              : "text-muted-foreground hover:bg-secondary hover:text-foreground",
          )}
        >
          <Shield className="size-4" />
          Administração
        </Link>
      )}
    </nav>
  );

  return (
    <div className="min-h-screen bg-background">
      <aside className="fixed inset-y-0 left-0 hidden w-64 border-r border-border bg-card p-4 md:block">
        <Link to="/painel" className="mb-8 flex items-center gap-2">
          <div className="grid size-9 place-items-center rounded-xl bg-hero-gradient text-primary-foreground">
            <Rocket className="size-5" />
          </div>
          <div className="leading-tight">
            <p className="text-sm font-bold">Agência MT Web</p>
            <p className="text-[11px] text-muted-foreground">Plataforma do representante</p>
          </div>
        </Link>
        {nav}
        <Button variant="ghost" className="mt-6 w-full justify-start gap-3" onClick={signOut}>
          <LogOut className="size-4" /> Sair
        </Button>
      </aside>

      <div className="md:pl-64">
        <header className="flex items-center justify-between gap-3 border-b border-border bg-card px-4 py-3">
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setOpen(!open)}
            aria-label="Abrir menu"
          >
            <Menu className="size-5" />
          </Button>
          <p className="text-sm text-muted-foreground">{userName ? `Olá, ${userName}` : ""}</p>
          <Button variant="ghost" size="sm" className="md:hidden" onClick={signOut}>
            Sair
          </Button>
        </header>
        {open && <div className="border-b border-border bg-card p-4 md:hidden">{nav}</div>}
        <main className="mx-auto max-w-6xl p-4 md:p-8">{children}</main>
      </div>
    </div>
  );
}
