import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Bell,
  ExternalLink,
  FileText,
  Mail,
  MessageCircle,
  Phone,
  Plus,
  Trash2,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useSession, useProfile } from "@/lib/auth";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  CHANNELS,
  INTERACTION_TYPES,
  STAGES,
  dateTimeBR,
  labelOf,
} from "@/lib/format";
import {
  APPROACH_TEMPLATES,
  buildApproachMessage,
  suggestTemplate,
  toWhatsappNumber,
  whatsappUrl,
  type ApproachTemplateId,
} from "@/lib/whatsapp";

export const Route = createFileRoute("/_authenticated/clientes")({
  head: () => ({
    meta: [
      { title: "Clientes e leads — Agência MT Web" },
      { name: "description", content: "Gerencie seus clientes, leads e o funil de vendas." },
      { property: "og:title", content: "Clientes e leads — Agência MT Web" },
      { property: "og:description", content: "CRM do representante." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Clientes,
});

const EMPTY = {
  company_name: "",
  contact_name: "",
  phone: "",
  email: "",
  city: "",
  state: "",
  segment: "",
  cnpj: "",
  website: "",
  social: "",
  source: "",
  stage: "novo_lead",
  notes: "",
};

type Client = {
  id: string;
  company_name: string;
  contact_name: string | null;
  phone: string | null;
  email: string | null;
  city: string | null;
  state: string | null;
  segment: string | null;
  website: string | null;
  instagram: string | null;
  facebook: string | null;
  social: string | null;
  source: string | null;
  stage: string;
  notes: string | null;
  next_action_at: string | null;
  next_action_note: string | null;
};

function Clientes() {
  const { user } = useSession();
  const { data: profileData } = useProfile(user);
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [search, setSearch] = useState("");
  const [stageFilter, setStageFilter] = useState("todos");
  const [detail, setDetail] = useState<Client | null>(null);
  const [confirmStage, setConfirmStage] = useState<Client | null>(null);
  const [approach, setApproach] = useState<
    { client: Client; template: ApproachTemplateId; message: string } | null
  >(null);
  const [interaction, setInteraction] = useState<
    { client: Client; channel: string; type: string; note: string; next: string } | null
  >(null);
  const [followUp, setFollowUp] = useState<
    { client: Client; at: string; reason: string } | null
  >(null);

  const repName = profileData?.profile?.full_name?.trim() || user?.email?.split("@")[0] || "";

  const { data: clients = [] } = useQuery({
    queryKey: ["clients", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("clients")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Client[];
    },
  });

  const { data: activities = [] } = useQuery({
    queryKey: ["lead-activities", detail?.id],
    enabled: !!detail,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("lead_activities")
        .select("*")
        .eq("client_id", detail!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const create = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("clients").insert({ ...form, owner_id: user!.id });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Cliente cadastrado.");
      setForm(EMPTY);
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["clients"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const updateClient = useMutation({
    mutationFn: async ({ id, values }: { id: string; values: Record<string, unknown> }) => {
      const { error } = await supabase.from("clients").update(values as never).eq("id", id);
      if (error) throw error;
    },
    onSuccess: (_r, variables) => {
      qc.invalidateQueries({ queryKey: ["clients"] });
      setDetail((current) =>
        current && current.id === variables.id
          ? ({ ...current, ...(variables.values as Partial<Client>) } as Client)
          : current,
      );
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("clients").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Cliente removido.");
      qc.invalidateQueries({ queryKey: ["clients"] });
    },
  });

  const logActivity = useMutation({
    mutationFn: async (values: {
      client_id: string;
      kind: string;
      channel?: string | null;
      interaction_type?: string | null;
      description: string;
      next_step?: string | null;
      due_date?: string | null;
    }) => {
      const { error } = await supabase
        .from("lead_activities")
        .insert({ owner_id: user!.id, ...values } as never);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["lead-activities"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const targetOf = (client: Client) => ({
    name: client.company_name,
    category: client.segment,
    city: client.city,
    state: client.state,
    website: client.website,
    instagram: client.instagram,
    facebook: client.facebook,
  });

  const openApproach = (client: Client) => {
    if (!toWhatsappNumber(client.phone)) {
      toast.error("Telefone não cadastrado ou inválido para WhatsApp.");
      return;
    }
    const target = targetOf(client);
    const template = suggestTemplate(target);
    setApproach({
      client,
      template,
      message: buildApproachMessage(target, template, repName, client.segment ?? ""),
    });
  };

  const openWhatsapp = () => {
    if (!approach) return;
    const number = toWhatsappNumber(approach.client.phone);
    if (!number) return;
    window.open(whatsappUrl(number, approach.message), "_blank", "noopener");
    logActivity.mutate({
      client_id: approach.client.id,
      kind: "whatsapp",
      channel: "whatsapp",
      interaction_type: "primeiro_contato",
      description: `Conversa aberta no WhatsApp: ${approach.message.slice(0, 200)}`,
    });
    if (approach.client.stage === "novo_lead") setConfirmStage(approach.client);
    setApproach(null);
  };

  const filtered = clients.filter(
    (c) =>
      (stageFilter === "todos" || c.stage === stageFilter) &&
      (c.company_name + (c.contact_name ?? "") + (c.city ?? ""))
        .toLowerCase()
        .includes(search.toLowerCase()),
  );

  const field = (key: keyof typeof EMPTY, label: string, type = "text") => (
    <div className="space-y-2">
      <Label htmlFor={key}>{label}</Label>
      <Input
        id={key}
        type={type}
        value={form[key]}
        onChange={(e) => setForm({ ...form, [key]: e.target.value })}
      />
    </div>
  );

  return (
    <div>
      <PageHeader
        title="Clientes e leads"
        subtitle="Somente você tem acesso a estes registros."
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="size-4" /> Novo cliente
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-2xl">
              <DialogHeader>
                <DialogTitle>Cadastrar cliente ou lead</DialogTitle>
              </DialogHeader>
              <form
                className="grid gap-4 sm:grid-cols-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  create.mutate();
                }}
              >
                <div className="sm:col-span-2">{field("company_name", "Nome da empresa *")}</div>
                {field("contact_name", "Responsável")}
                {field("phone", "Telefone")}
                {field("email", "E-mail", "email")}
                {field("segment", "Segmento")}
                {field("city", "Cidade")}
                {field("state", "Estado")}
                {field("cnpj", "CNPJ")}
                {field("website", "Site atual")}
                {field("social", "Redes sociais")}
                {field("source", "Origem do lead")}
                <div className="space-y-2">
                  <Label>Etapa do funil</Label>
                  <Select
                    value={form.stage}
                    onValueChange={(v) => setForm({ ...form, stage: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STAGES.map((s) => (
                        <SelectItem key={s.value} value={s.value}>
                          {s.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="notes">Observações</Label>
                  <Textarea
                    id="notes"
                    value={form.notes}
                    onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  />
                </div>
                <Button type="submit" className="sm:col-span-2" disabled={create.isPending}>
                  Salvar cliente
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="mb-4 flex flex-wrap gap-3">
        <Input
          placeholder="Buscar por empresa, responsável ou cidade"
          className="max-w-sm"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <Select value={stageFilter} onValueChange={setStageFilter}>
          <SelectTrigger className="w-56">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todas as etapas</SelectItem>
            {STAGES.map((s) => (
              <SelectItem key={s.value} value={s.value}>
                {s.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-3">
        {filtered.map((c) => (
          <Card key={c.id} className="shadow-card">
            <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
              <div>
                <p className="font-semibold">{c.company_name}</p>
                <p className="text-sm text-muted-foreground">
                  {[c.contact_name, c.phone, c.email].filter(Boolean).join(" · ") || "Sem contato"}
                </p>
                <p className="text-xs text-muted-foreground">
                  {[c.segment, c.city, c.state].filter(Boolean).join(" · ")}
                </p>
                {c.next_action_at && (
                  <p className="mt-1 text-xs font-medium text-primary">
                    Próximo contato: {dateTimeBR(c.next_action_at)}
                    {c.next_action_note ? ` — ${c.next_action_note}` : ""}
                  </p>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {toWhatsappNumber(c.phone) && (
                  <Button size="sm" className="gap-1.5" onClick={() => openApproach(c)}>
                    <MessageCircle className="size-4" /> WhatsApp
                  </Button>
                )}
                <Button variant="outline" size="sm" onClick={() => setDetail(c)}>
                  Ver detalhes
                </Button>
                <Select
                  value={c.stage}
                  onValueChange={(v) => updateClient.mutate({ id: c.id, values: { stage: v } })}
                >
                  <SelectTrigger className="w-48">
                    <SelectValue>{labelOf(STAGES, c.stage)}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    {STAGES.map((s) => (
                      <SelectItem key={s.value} value={s.value}>
                        {s.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button variant="ghost" size="icon" onClick={() => remove.mutate(c.id)}>
                  <Trash2 className="size-4 text-destructive" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {filtered.length === 0 && (
          <p className="text-sm text-muted-foreground">Nenhum cliente encontrado.</p>
        )}
      </div>

      {/* Detalhes do lead */}
      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          {detail && (
            <>
              <DialogHeader>
                <DialogTitle>{detail.company_name}</DialogTitle>
                <DialogDescription>
                  {[detail.contact_name, detail.segment, detail.city, detail.state]
                    .filter(Boolean)
                    .join(" · ") || "Sem dados complementares"}
                </DialogDescription>
              </DialogHeader>

              <div className="flex flex-wrap gap-2">
                {toWhatsappNumber(detail.phone) && (
                  <Button className="gap-1.5" onClick={() => openApproach(detail)}>
                    <MessageCircle className="size-4" /> Continuar conversa no WhatsApp
                  </Button>
                )}
                {detail.phone && (
                  <Button variant="outline" size="sm" asChild>
                    <a href={`tel:${detail.phone.replace(/\s/g, "")}`}>
                      <Phone className="mr-1 size-3" /> Ligar
                    </a>
                  </Button>
                )}
                {detail.email && (
                  <Button variant="outline" size="sm" asChild>
                    <a href={`mailto:${detail.email}`}>
                      <Mail className="mr-1 size-3" /> E-mail
                    </a>
                  </Button>
                )}
                {detail.website && (
                  <Button variant="ghost" size="sm" asChild>
                    <a href={detail.website} target="_blank" rel="noreferrer">
                      Website <ExternalLink className="ml-1 size-3" />
                    </a>
                  </Button>
                )}
                {detail.instagram && (
                  <Button variant="ghost" size="sm" asChild>
                    <a href={detail.instagram} target="_blank" rel="noreferrer">
                      Instagram <ExternalLink className="ml-1 size-3" />
                    </a>
                  </Button>
                )}
                {detail.facebook && (
                  <Button variant="ghost" size="sm" asChild>
                    <a href={detail.facebook} target="_blank" rel="noreferrer">
                      Facebook <ExternalLink className="ml-1 size-3" />
                    </a>
                  </Button>
                )}
              </div>

              <div className="flex flex-wrap gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-1.5"
                  onClick={() =>
                    setInteraction({
                      client: detail,
                      channel: "whatsapp",
                      type: "retorno",
                      note: "",
                      next: "",
                    })
                  }
                >
                  <Plus className="size-4" /> Registrar interação
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-1.5"
                  onClick={() => setFollowUp({ client: detail, at: "", reason: "" })}
                >
                  <Bell className="size-4" /> Agendar follow-up
                </Button>
                <Button variant="outline" size="sm" className="gap-1.5" asChild>
                  <Link to="/propostas" search={{ cliente: detail.id }}>
                    <FileText className="size-4" /> Criar proposta
                  </Link>
                </Button>
              </div>

              <div className="space-y-2">
                <Label>Etapa do funil</Label>
                <Select
                  value={detail.stage}
                  onValueChange={(v) =>
                    updateClient.mutate({ id: detail.id, values: { stage: v } })
                  }
                >
                  <SelectTrigger>
                    <SelectValue>{labelOf(STAGES, detail.stage)}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    {STAGES.map((s) => (
                      <SelectItem key={s.value} value={s.value}>
                        {s.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Próxima ação</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  {detail.next_action_at
                    ? `${dateTimeBR(detail.next_action_at)} — ${detail.next_action_note ?? "Sem descrição"}`
                    : "Nenhum próximo contato agendado."}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Histórico de atendimento</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  {activities.map((a) => (
                    <div key={a.id} className="border-b border-border pb-2 last:border-0">
                      <p className="text-xs text-muted-foreground">{dateTimeBR(a.created_at)}</p>
                      <p className="font-medium">
                        {labelOf(CHANNELS, a.channel ?? a.kind)}
                        {a.interaction_type ? ` · ${labelOf(INTERACTION_TYPES, a.interaction_type)}` : ""}
                      </p>
                      <p className="text-muted-foreground">{a.description}</p>
                      {a.next_step && (
                        <p className="text-xs text-primary">Próximo passo: {a.next_step}</p>
                      )}
                    </div>
                  ))}
                  {activities.length === 0 && (
                    <p className="text-muted-foreground">Nenhuma interação registrada ainda.</p>
                  )}
                </CardContent>
              </Card>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Mensagem de abordagem */}
      <Dialog open={!!approach} onOpenChange={(o) => !o && setApproach(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          {approach && (
            <>
              <DialogHeader>
                <DialogTitle>Mensagem de abordagem</DialogTitle>
                <DialogDescription>
                  Revise e edite antes de abrir o WhatsApp. O envio continua manual, feito por você.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-2">
                <Label htmlFor="crm-template">Modelo de abordagem</Label>
                <Select
                  value={approach.template}
                  onValueChange={(value) =>
                    setApproach({
                      ...approach,
                      template: value as ApproachTemplateId,
                      message: buildApproachMessage(
                        targetOf(approach.client),
                        value as ApproachTemplateId,
                        repName,
                        approach.client.segment ?? "",
                      ),
                    })
                  }
                >
                  <SelectTrigger id="crm-template">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {APPROACH_TEMPLATES.map((item) => (
                      <SelectItem key={item.id} value={item.id}>
                        {item.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="crm-message">Mensagem</Label>
                <Textarea
                  id="crm-message"
                  rows={10}
                  value={approach.message}
                  onChange={(e) => setApproach({ ...approach, message: e.target.value })}
                />
              </div>
              <DialogFooter className="flex-col gap-2 sm:flex-row">
                <Button variant="ghost" onClick={() => setApproach(null)}>
                  ← Voltar
                </Button>
                <Button
                  variant="outline"
                  onClick={() =>
                    navigator.clipboard.writeText(approach.message).then(
                      () => toast.success("Mensagem copiada."),
                      () => toast.error("Não foi possível copiar a mensagem."),
                    )
                  }
                >
                  Copiar mensagem
                </Button>
                <Button className="gap-1.5" onClick={openWhatsapp}>
                  <MessageCircle className="size-4" /> Abrir WhatsApp
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Confirmar mudança de etapa */}
      <Dialog open={!!confirmStage} onOpenChange={(o) => !o && setConfirmStage(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Registrar este contato como iniciado?</DialogTitle>
            <DialogDescription>
              A etapa do funil passará de "Novo lead" para "Contato iniciado".
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmStage(null)}>
              Não
            </Button>
            <Button
              onClick={() => {
                if (confirmStage) {
                  updateClient.mutate({
                    id: confirmStage.id,
                    values: { stage: "contato_iniciado" },
                  });
                }
                setConfirmStage(null);
              }}
            >
              Sim
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Registrar interação */}
      <Dialog open={!!interaction} onOpenChange={(o) => !o && setInteraction(null)}>
        <DialogContent className="sm:max-w-lg">
          {interaction && (
            <>
              <DialogHeader>
                <DialogTitle>Registrar interação</DialogTitle>
                <DialogDescription>{interaction.client.company_name}</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Canal</Label>
                  <Select
                    value={interaction.channel}
                    onValueChange={(v) => setInteraction({ ...interaction, channel: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CHANNELS.map((c) => (
                        <SelectItem key={c.value} value={c.value}>
                          {c.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Tipo de interação</Label>
                  <Select
                    value={interaction.type}
                    onValueChange={(v) => setInteraction({ ...interaction, type: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {INTERACTION_TYPES.map((t) => (
                        <SelectItem key={t.value} value={t.value}>
                          {t.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="int-note">Observação</Label>
                  <Textarea
                    id="int-note"
                    rows={3}
                    value={interaction.note}
                    onChange={(e) => setInteraction({ ...interaction, note: e.target.value })}
                    placeholder="Cliente demonstrou interesse em criar um site e pediu orçamento."
                  />
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="int-next">Próximo passo (opcional)</Label>
                  <Input
                    id="int-next"
                    value={interaction.next}
                    onChange={(e) => setInteraction({ ...interaction, next: e.target.value })}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setInteraction(null)}>
                  Cancelar
                </Button>
                <Button
                  disabled={logActivity.isPending}
                  onClick={() => {
                    if (!interaction.note.trim()) {
                      toast.error("Escreva uma observação sobre a interação.");
                      return;
                    }
                    logActivity.mutate(
                      {
                        client_id: interaction.client.id,
                        kind: interaction.channel,
                        channel: interaction.channel,
                        interaction_type: interaction.type,
                        description: interaction.note.trim(),
                        next_step: interaction.next.trim() || null,
                      },
                      {
                        onSuccess: () => {
                          toast.success("Interação registrada.");
                          setInteraction(null);
                        },
                      },
                    );
                  }}
                >
                  Salvar
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Follow-up */}
      <Dialog open={!!followUp} onOpenChange={(o) => !o && setFollowUp(null)}>
        <DialogContent className="sm:max-w-md">
          {followUp && (
            <>
              <DialogHeader>
                <DialogTitle>Agendar follow-up</DialogTitle>
                <DialogDescription>{followUp.client.company_name}</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="fu-at">Data e hora</Label>
                  <Input
                    id="fu-at"
                    type="datetime-local"
                    value={followUp.at}
                    onChange={(e) => setFollowUp({ ...followUp, at: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="fu-reason">Motivo / observação</Label>
                  <Textarea
                    id="fu-reason"
                    rows={3}
                    value={followUp.reason}
                    onChange={(e) => setFollowUp({ ...followUp, reason: e.target.value })}
                    placeholder="Retornar contato para saber se aprovou a proposta."
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setFollowUp(null)}>
                  Cancelar
                </Button>
                <Button
                  onClick={() => {
                    if (!followUp.at) {
                      toast.error("Informe a data e a hora do follow-up.");
                      return;
                    }
                    const iso = new Date(followUp.at).toISOString();
                    updateClient.mutate({
                      id: followUp.client.id,
                      values: { next_action_at: iso, next_action_note: followUp.reason.trim() },
                    });
                    logActivity.mutate({
                      client_id: followUp.client.id,
                      kind: "follow_up",
                      channel: "whatsapp",
                      interaction_type: "follow_up",
                      description: `Follow-up agendado para ${dateTimeBR(iso)}${
                        followUp.reason.trim() ? ` — ${followUp.reason.trim()}` : ""
                      }`,
                      next_step: followUp.reason.trim() || null,
                      due_date: iso.slice(0, 10),
                    });
                    toast.success("Follow-up agendado.");
                    setFollowUp(null);
                  }}
                >
                  Salvar
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
