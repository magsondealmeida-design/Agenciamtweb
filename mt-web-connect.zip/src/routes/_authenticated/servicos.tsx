import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useSession, useProfile } from "@/lib/auth";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { brl } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/servicos")({
  head: () => ({
    meta: [
      { title: "Catálogo de serviços — Agência MT Web" },
      { name: "description", content: "Serviços digitais disponíveis para venda aos clientes." },
      { property: "og:title", content: "Catálogo de serviços — Agência MT Web" },
      { property: "og:description", content: "Serviços que o representante pode vender." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Servicos,
});

const EMPTY = {
  name: "",
  description: "",
  category: "",
  suggested_price: "0",
  estimated_days: "7",
  commission_percent: "30",
};

function Servicos() {
  const { user } = useSession();
  const { data: me } = useProfile(user);
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY);

  const { data: services = [] } = useQuery({
    queryKey: ["services"],
    queryFn: async () => {
      const { data, error } = await supabase.from("services").select("*").order("name");
      if (error) throw error;
      return data;
    },
  });

  const create = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("services").insert({
        name: form.name,
        description: form.description,
        category: form.category,
        suggested_price: Number(form.suggested_price),
        estimated_days: Number(form.estimated_days),
        commission_percent: Number(form.commission_percent),
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Serviço cadastrado.");
      setForm(EMPTY);
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["services"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const toggle = useMutation({
    mutationFn: async ({ id, active }: { id: string; active: boolean }) => {
      const { error } = await supabase.from("services").update({ active }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["services"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div>
      <PageHeader
        title="Catálogo de serviços"
        subtitle="Use estes serviços para montar suas propostas comerciais."
        action={
          me?.isAdmin ? (
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus className="size-4" /> Novo serviço
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Cadastrar serviço</DialogTitle>
                </DialogHeader>
                <form
                  className="space-y-4"
                  onSubmit={(e) => {
                    e.preventDefault();
                    create.mutate();
                  }}
                >
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome</Label>
                    <Input
                      id="name"
                      required
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Descrição</Label>
                    <Textarea
                      id="description"
                      value={form.description}
                      onChange={(e) => setForm({ ...form, description: e.target.value })}
                    />
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="category">Categoria</Label>
                      <Input
                        id="category"
                        value={form.category}
                        onChange={(e) => setForm({ ...form, category: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="price">Preço sugerido</Label>
                      <Input
                        id="price"
                        type="number"
                        step="0.01"
                        value={form.suggested_price}
                        onChange={(e) => setForm({ ...form, suggested_price: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="days">Prazo (dias)</Label>
                      <Input
                        id="days"
                        type="number"
                        value={form.estimated_days}
                        onChange={(e) => setForm({ ...form, estimated_days: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="comm">Comissão (%)</Label>
                      <Input
                        id="comm"
                        type="number"
                        value={form.commission_percent}
                        onChange={(e) => setForm({ ...form, commission_percent: e.target.value })}
                      />
                    </div>
                  </div>
                  <Button type="submit" className="w-full">
                    Salvar serviço
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          ) : undefined
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {services.map((s) => (
          <Card key={s.id} className="shadow-card">
            <CardContent className="p-5">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-semibold">{s.name}</p>
                  <p className="text-xs uppercase tracking-wide text-muted-foreground">
                    {s.category}
                  </p>
                </div>
                {me?.isAdmin && (
                  <Switch
                    checked={s.active}
                    onCheckedChange={(v) => toggle.mutate({ id: s.id, active: v })}
                  />
                )}
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{s.description}</p>
              <div className="mt-4 flex items-center justify-between text-sm">
                <span className="font-semibold text-primary">{brl(s.suggested_price)}</span>
                <span className="text-muted-foreground">{s.estimated_days} dias</span>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                Comissão do representante: {s.commission_percent}%
              </p>
              {!s.active && <p className="mt-2 text-xs text-destructive">Inativo</p>}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
