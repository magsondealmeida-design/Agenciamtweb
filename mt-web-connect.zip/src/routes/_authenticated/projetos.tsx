import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/auth";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { brl, dateBR, labelOf, PROJECT_STATUS } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/projetos")({
  head: () => ({
    meta: [
      { title: "Projetos — Agência MT Web" },
      { name: "description", content: "Acompanhe a execução dos serviços vendidos aos clientes." },
      { property: "og:title", content: "Projetos — Agência MT Web" },
      { property: "og:description", content: "Gestão de projetos do representante." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Projetos,
});

function Projetos() {
  const { user } = useSession();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    name: "",
    client_id: "",
    service_name: "",
    amount: "0",
    start_date: "",
    due_date: "",
    notes: "",
  });

  const { data: clients = [] } = useQuery({
    queryKey: ["clients", user?.id],
    enabled: !!user,
    queryFn: async () => (await supabase.from("clients").select("id, company_name")).data ?? [],
  });

  const { data: projects = [] } = useQuery({
    queryKey: ["projects", user?.id],
    enabled: !!user,
    queryFn: async () =>
      (
        await supabase
          .from("projects")
          .select("*, clients(company_name)")
          .order("created_at", { ascending: false })
      ).data ?? [],
  });

  const create = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("projects").insert({
        owner_id: user!.id,
        name: form.name,
        client_id: form.client_id || null,
        service_name: form.service_name,
        amount: Number(form.amount || 0),
        start_date: form.start_date || null,
        due_date: form.due_date || null,
        notes: form.notes,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Projeto criado.");
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["projects"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const setStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("projects").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["projects"] }),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("projects").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["projects"] }),
  });

  return (
    <div>
      <PageHeader
        title="Projetos"
        subtitle="Controle os serviços contratados pelos seus clientes."
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="size-4" /> Novo projeto
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[85vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Novo projeto</DialogTitle>
              </DialogHeader>
              <form
                className="space-y-4"
                onSubmit={(e) => {
                  e.preventDefault();
                  create.mutate();
                }}
              >
                <div className="space-y-2">
                  <Label htmlFor="pname">Nome do projeto</Label>
                  <Input
                    id="pname"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Cliente</Label>
                  <Select
                    value={form.client_id}
                    onValueChange={(v) => setForm({ ...form, client_id: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      {clients.map((c) => (
                        <SelectItem key={c.id} value={c.id}>
                          {c.company_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="service">Serviço contratado</Label>
                    <Input
                      id="service"
                      value={form.service_name}
                      onChange={(e) => setForm({ ...form, service_name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="amount">Valor</Label>
                    <Input
                      id="amount"
                      type="number"
                      step="0.01"
                      value={form.amount}
                      onChange={(e) => setForm({ ...form, amount: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="start">Início</Label>
                    <Input
                      id="start"
                      type="date"
                      value={form.start_date}
                      onChange={(e) => setForm({ ...form, start_date: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="due">Prazo</Label>
                    <Input
                      id="due"
                      type="date"
                      value={form.due_date}
                      onChange={(e) => setForm({ ...form, due_date: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pnotes">Observações</Label>
                  <Textarea
                    id="pnotes"
                    value={form.notes}
                    onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  />
                </div>
                <Button type="submit" className="w-full">
                  Criar projeto
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        }
      />

      <Tabs defaultValue="lista">
        <TabsList>
          <TabsTrigger value="lista">Lista</TabsTrigger>
          <TabsTrigger value="kanban">Kanban</TabsTrigger>
        </TabsList>

        <TabsContent value="lista" className="mt-4 grid gap-3">
          {projects.map((p) => (
            <Card key={p.id} className="shadow-card">
              <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
                <div>
                  <p className="font-semibold">{p.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {p.clients?.company_name ?? "Sem cliente"} · {brl(p.amount)} · prazo{" "}
                    {dateBR(p.due_date)}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Select
                    value={p.status}
                    onValueChange={(v) => setStatus.mutate({ id: p.id, status: v })}
                  >
                    <SelectTrigger className="w-52">
                      <SelectValue>{labelOf(PROJECT_STATUS, p.status)}</SelectValue>
                    </SelectTrigger>
                    <SelectContent>
                      {PROJECT_STATUS.map((s) => (
                        <SelectItem key={s.value} value={s.value}>
                          {s.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button variant="ghost" size="icon" onClick={() => remove.mutate(p.id)}>
                    <Trash2 className="size-4 text-destructive" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
          {projects.length === 0 && (
            <p className="text-sm text-muted-foreground">Nenhum projeto cadastrado ainda.</p>
          )}
        </TabsContent>

        <TabsContent value="kanban" className="mt-4">
          <div className="grid gap-4 md:grid-cols-3 xl:grid-cols-6">
            {PROJECT_STATUS.map((s) => (
              <div key={s.value} className="rounded-xl bg-secondary/60 p-3">
                <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  {s.label}
                </p>
                <div className="space-y-2">
                  {projects
                    .filter((p) => p.status === s.value)
                    .map((p) => (
                      <div key={p.id} className="rounded-lg bg-card p-3 text-sm shadow-card">
                        <p className="font-medium">{p.name}</p>
                        <p className="text-xs text-muted-foreground">{p.clients?.company_name}</p>
                        <p className="mt-1 text-xs font-semibold text-primary">{brl(p.amount)}</p>
                      </div>
                    ))}
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
