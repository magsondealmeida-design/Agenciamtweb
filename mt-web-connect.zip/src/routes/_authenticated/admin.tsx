import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useSession, useProfile } from "@/lib/auth";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { brl, dateBR } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Administração — Agência MT Web" },
      { name: "description", content: "Painel do administrador: representantes, planos e assinaturas." },
      { property: "og:title", content: "Administração — Agência MT Web" },
      { property: "og:description", content: "Gestão central da plataforma." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Admin,
});

function Admin() {
  const { user } = useSession();
  const { data: me, isLoading } = useProfile(user);
  const qc = useQueryClient();
  const [planOpen, setPlanOpen] = useState(false);
  const [plan, setPlan] = useState({
    name: "",
    description: "",
    price_monthly: "0",
    max_clients: "50",
    max_projects: "50",
    max_contents: "50",
    prospecting_search_limit: "10",
    prospecting_results_limit: "20",
  });
  const [assign, setAssign] = useState({ user_id: "", plan_id: "", status: "ativa" });

  const enabled = !!me?.isAdmin;

  const { data } = useQuery({
    queryKey: ["admin-data"],
    enabled,
    queryFn: async () => {
      const [profiles, roles, plans, subs, clients, projects] = await Promise.all([
        supabase.from("profiles").select("*").order("created_at", { ascending: false }),
        supabase.from("user_roles").select("*"),
        supabase.from("subscription_plans").select("*").order("price_monthly"),
        supabase.from("subscriptions").select("*, subscription_plans(name)"),
        supabase.from("clients").select("id"),
        supabase.from("projects").select("id, status"),
      ]);
      return {
        profiles: profiles.data ?? [],
        roles: roles.data ?? [],
        plans: plans.data ?? [],
        subs: subs.data ?? [],
        clients: clients.data ?? [],
        projects: projects.data ?? [],
      };
    },
  });

  const createPlan = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("subscription_plans").insert({
        name: plan.name,
        description: plan.description,
        price_monthly: Number(plan.price_monthly),
        max_clients: Number(plan.max_clients),
        max_projects: Number(plan.max_projects),
        max_contents: Number(plan.max_contents),
        prospecting_search_limit: Number(plan.prospecting_search_limit),
        prospecting_results_limit: Number(plan.prospecting_results_limit),
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Plano criado.");
      setPlanOpen(false);
      qc.invalidateQueries({ queryKey: ["admin-data"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const togglePlan = useMutation({
    mutationFn: async ({ id, active }: { id: string; active: boolean }) => {
      const { error } = await supabase.from("subscription_plans").update({ active }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-data"] }),
  });

  const saveSubscription = useMutation({
    mutationFn: async () => {
      if (!assign.user_id || !assign.plan_id) throw new Error("Selecione o representante e o plano.");
      const { error } = await supabase.from("subscriptions").insert({
        user_id: assign.user_id,
        plan_id: assign.plan_id,
        status: assign.status,
        started_at: new Date().toISOString().slice(0, 10),
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Assinatura registrada.");
      qc.invalidateQueries({ queryKey: ["admin-data"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (isLoading) return <p className="text-sm text-muted-foreground">Carregando...</p>;
  if (!me?.isAdmin)
    return (
      <p className="text-sm text-muted-foreground">
        Esta área é exclusiva do administrador da plataforma.
      </p>
    );

  const subs = data?.subs ?? [];
  const activeSubs = subs.filter((s) => s.status === "ativa");
  const mrr = activeSubs.length;

  return (
    <div>
      <PageHeader title="Administração" subtitle="Gestão central da Agência MT Web." />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Representantes" value={data?.profiles.length ?? 0} />
        <StatCard label="Assinaturas ativas" value={activeSubs.length} hint={`${mrr} cobranças/mês`} />
        <StatCard label="Clientes na base" value={data?.clients.length ?? 0} />
        <StatCard
          label="Projetos em andamento"
          value={(data?.projects ?? []).filter((p) => p.status === "andamento").length}
        />
      </div>

      <Tabs defaultValue="usuarios" className="mt-6">
        <TabsList>
          <TabsTrigger value="usuarios">Representantes</TabsTrigger>
          <TabsTrigger value="planos">Planos</TabsTrigger>
          <TabsTrigger value="assinaturas">Assinaturas</TabsTrigger>
        </TabsList>

        <TabsContent value="usuarios" className="mt-4 grid gap-3">
          {(data?.profiles ?? []).map((p) => {
            const roles = (data?.roles ?? [])
              .filter((r) => r.user_id === p.id)
              .map((r) => r.role)
              .join(", ");
            return (
              <Card key={p.id} className="shadow-card">
                <CardContent className="flex flex-wrap items-center justify-between gap-2 p-4">
                  <div>
                    <p className="font-medium">{p.full_name ?? "Sem nome"}</p>
                    <p className="text-xs text-muted-foreground">
                      {[p.phone, p.city, p.state].filter(Boolean).join(" · ")} · desde{" "}
                      {dateBR(p.created_at.slice(0, 10))}
                    </p>
                  </div>
                  <span className="rounded-full bg-secondary px-3 py-1 text-xs">{roles}</span>
                </CardContent>
              </Card>
            );
          })}
        </TabsContent>

        <TabsContent value="planos" className="mt-4">
          <Dialog open={planOpen} onOpenChange={setPlanOpen}>
            <DialogTrigger asChild>
              <Button className="mb-4 gap-2">
                <Plus className="size-4" /> Novo plano
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Novo plano</DialogTitle>
              </DialogHeader>
              <form
                className="space-y-4"
                onSubmit={(e) => {
                  e.preventDefault();
                  createPlan.mutate();
                }}
              >
                <div className="space-y-2">
                  <Label htmlFor="pn">Nome</Label>
                  <Input
                    id="pn"
                    required
                    value={plan.name}
                    onChange={(e) => setPlan({ ...plan, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pd">Descrição</Label>
                  <Textarea
                    id="pd"
                    value={plan.description}
                    onChange={(e) => setPlan({ ...plan, description: e.target.value })}
                  />
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="pp">Preço mensal</Label>
                    <Input
                      id="pp"
                      type="number"
                      step="0.01"
                      value={plan.price_monthly}
                      onChange={(e) => setPlan({ ...plan, price_monthly: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="ps">Pesquisas do Radar/mês</Label>
                    <Input id="ps" type="number" min="0" value={plan.prospecting_search_limit} onChange={(e) => setPlan({ ...plan, prospecting_search_limit: e.target.value })} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="pr">Resultados por pesquisa</Label>
                    <Input id="pr" type="number" min="1" max="20" value={plan.prospecting_results_limit} onChange={(e) => setPlan({ ...plan, prospecting_results_limit: e.target.value })} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="pc">Limite de clientes</Label>
                    <Input
                      id="pc"
                      type="number"
                      value={plan.max_clients}
                      onChange={(e) => setPlan({ ...plan, max_clients: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="pj">Limite de projetos</Label>
                    <Input
                      id="pj"
                      type="number"
                      value={plan.max_projects}
                      onChange={(e) => setPlan({ ...plan, max_projects: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="pt">Limite de conteúdos</Label>
                    <Input
                      id="pt"
                      type="number"
                      value={plan.max_contents}
                      onChange={(e) => setPlan({ ...plan, max_contents: e.target.value })}
                    />
                  </div>
                </div>
                <Button type="submit" className="w-full">
                  Salvar plano
                </Button>
              </form>
            </DialogContent>
          </Dialog>

          <div className="grid gap-3">
            {(data?.plans ?? []).map((p) => (
              <Card key={p.id} className="shadow-card">
                <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
                  <div>
                    <p className="font-semibold">
                      {p.name} — {brl(p.price_monthly)}/mês
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {p.max_clients} clientes · {p.max_projects} projetos · {p.max_contents}{" "}
                      conteúdos · {p.prospecting_search_limit} pesquisas/mês · até {p.prospecting_results_limit} resultados
                    </p>
                  </div>
                  <Switch
                    checked={p.active}
                    onCheckedChange={(v) => togglePlan.mutate({ id: p.id, active: v })}
                  />
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="assinaturas" className="mt-4 space-y-4">
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>Ativar assinatura manualmente</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-3 sm:grid-cols-4">
              <Select
                value={assign.user_id}
                onValueChange={(v) => setAssign({ ...assign, user_id: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Representante" />
                </SelectTrigger>
                <SelectContent>
                  {(data?.profiles ?? []).map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.full_name ?? p.id.slice(0, 8)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select
                value={assign.plan_id}
                onValueChange={(v) => setAssign({ ...assign, plan_id: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Plano" />
                </SelectTrigger>
                <SelectContent>
                  {(data?.plans ?? []).map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select
                value={assign.status}
                onValueChange={(v) => setAssign({ ...assign, status: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ativa">Ativa</SelectItem>
                  <SelectItem value="pendente">Pendente</SelectItem>
                  <SelectItem value="cancelada">Cancelada</SelectItem>
                </SelectContent>
              </Select>
              <Button onClick={() => saveSubscription.mutate()}>Registrar</Button>
            </CardContent>
          </Card>

          <div className="grid gap-3">
            {subs.map((s) => (
              <Card key={s.id} className="shadow-card">
                <CardContent className="flex items-center justify-between p-4 text-sm">
                  <span>
                    {(data?.profiles ?? []).find((p) => p.id === s.user_id)?.full_name ??
                      s.user_id.slice(0, 8)}{" "}
                    · {s.subscription_plans?.name}
                  </span>
                  <span className="text-muted-foreground">{s.status}</span>
                </CardContent>
              </Card>
            ))}
          </div>
          <p className="text-xs text-muted-foreground">
            O pagamento recorrente automático ainda não está integrado: as assinaturas são
            confirmadas manualmente aqui.
          </p>
        </TabsContent>
      </Tabs>
    </div>
  );
}
