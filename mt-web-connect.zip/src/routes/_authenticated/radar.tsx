import { useMemo, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  Building2,
  CheckCircle2,
  Copy,
  ExternalLink,
  Globe2,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  Search,
  Target,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";
import { searchProspects, type RadarCompany } from "@/lib/radar.functions";
import {
  APPROACH_TEMPLATES,
  buildApproachMessage,
  suggestTemplate,
  toWhatsappNumber,
  whatsappUrl,
  type ApproachTemplateId,
  type RadarStatus,
} from "@/lib/whatsapp";
import { supabase } from "@/integrations/supabase/client";
import { useSession, useProfile } from "@/lib/auth";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";


export const Route = createFileRoute("/_authenticated/radar")({
  head: () => ({
    meta: [
      { title: "Radar de Prospecção — Agência MT Web" },
      { name: "description", content: "Encontre empresas e transforme oportunidades digitais em leads." },
      { property: "og:title", content: "Radar de Prospecção — Agência MT Web" },
      { property: "og:description", content: "Pesquisa e qualificação comercial de empresas." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Radar,
});

const opportunity = (company: RadarCompany) => {
  if (!company.website) return "Possível oportunidade para criação de site";
  if (!company.instagram && !company.facebook) return "Presença digital parcial";
  return "Presença digital identificada";
};

function Status({ found, label }: { found: boolean; label: string }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-border py-2 last:border-0">
      <span className="text-sm font-medium">{label}</span>
      <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
        {found ? <CheckCircle2 className="size-4 text-success" /> : <XCircle className="size-4 text-destructive" />}
        {found ? "Encontrado" : "Não identificado"}
      </span>
    </div>
  );
}

function Radar() {
  const { user } = useSession();
  const { data: profileData } = useProfile(user);
  const qc = useQueryClient();
  const navigate = useNavigate();
  const searchFn = useServerFn(searchProspects);
  const [form, setForm] = useState({ city: "", state: "MT", segment: "", keyword: "", requested: "10" });
  const [companies, setCompanies] = useState<RadarCompany[]>([]);
  const [selected, setSelected] = useState<RadarCompany | null>(null);
  const [filter, setFilter] = useState("todos");
  const [usage, setUsage] = useState<{ used: number; limit: number; resultLimit: number } | null>(null);
  const [statuses, setStatuses] = useState<Record<string, RadarStatus>>({});
  const [approach, setApproach] = useState<
    { company: RadarCompany; template: ApproachTemplateId; message: string } | null
  >(null);
  const repName = profileData?.profile?.full_name?.trim() || user?.email?.split("@")[0] || "";


  const { data: existing = [] } = useQuery({
    queryKey: ["radar-clients", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("clients").select("id, place_id").not("place_id", "is", null);
      return data ?? [];
    },
  });

  const search = useMutation({
    mutationFn: () =>
      searchFn({
        data: {
          city: form.city,
          state: form.state.toUpperCase(),
          segment: form.segment,
          keyword: form.keyword,
          requested: Number(form.requested),
        },
      }),
    onSuccess: (result) => {
      setCompanies(result.companies);
      setUsage(result.usage);
      if (result.companies.length === 0) toast.info("Nenhuma empresa encontrada para esta pesquisa.");
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const addLead = useMutation({
    mutationFn: async (company: RadarCompany) => {
      if (!user) throw new Error("Sua sessão expirou. Entre novamente.");
      if (existing.some((item) => item.place_id === company.placeId)) {
        throw new Error("Esta empresa já está cadastrada.");
      }
      const { data: client, error } = await supabase
        .from("clients")
        .insert({
          owner_id: user.id,
          company_name: company.name,
          phone: company.phone,
          city: company.city,
          state: company.state,
          segment: company.category ?? form.segment,
          website: company.website,
          address: company.address,
          postal_code: company.postalCode,
          instagram: company.instagram,
          facebook: company.facebook,
          place_id: company.placeId,
          source: "Radar · Google Places",
          found_at: company.searchedAt,
          digital_presence: opportunity(company),
          stage: "novo_lead",
          notes: `Empresa encontrada pelo Radar em ${new Date(company.searchedAt).toLocaleDateString("pt-BR")}.`,
        })
        .select("id")
        .single();
      if (error) {
        if (error.code === "23505") throw new Error("Esta empresa já está cadastrada.");
        throw error;
      }
      const { error: historyError } = await supabase.from("lead_activities").insert([
        { owner_id: user.id, client_id: client.id, kind: "radar", description: "Empresa encontrada pelo Radar" },
        { owner_id: user.id, client_id: client.id, kind: "cadastro", description: "Adicionada ao CRM" },
      ]);
      if (historyError) throw historyError;
      return client.id;
    },
    onSuccess: () => {
      toast.success("Empresa adicionada ao CRM.");
      qc.invalidateQueries({ queryKey: ["radar-clients"] });
      qc.invalidateQueries({ queryKey: ["clients"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const registerContact = useMutation({
    mutationFn: async ({ company, message }: { company: RadarCompany; message: string }) => {
      if (!user) throw new Error("Sua sessão expirou. Entre novamente.");
      let clientId = existing.find((item) => item.place_id === company.placeId)?.id;
      if (!clientId) clientId = await addLead.mutateAsync(company);
      const { error } = await supabase.from("lead_activities").insert({
        owner_id: user.id,
        client_id: clientId,
        kind: "whatsapp",
        description: `Contato iniciado por WhatsApp — abordagem enviada para revisão: ${message.slice(0, 200)}`,
      });
      if (error) throw error;
    },
    onSuccess: (_result, variables) => {
      setStatuses((prev) => ({ ...prev, [variables.company.placeId]: "Contato iniciado" }));
      qc.invalidateQueries({ queryKey: ["radar-clients"] });
      qc.invalidateQueries({ queryKey: ["clients"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const openApproach = (company: RadarCompany) => {
    const number = toWhatsappNumber(company.phone);
    if (!number) {
      toast.error("Telefone não identificado ou inválido para WhatsApp.");
      return;
    }
    const template = suggestTemplate(company);
    setApproach({
      company,
      template,
      message: buildApproachMessage(company, template, repName, form.segment),
    });
  };

  const openWhatsapp = () => {
    if (!approach) return;
    const number = toWhatsappNumber(approach.company.phone);
    if (!number) {
      toast.error("Telefone não identificado ou inválido para WhatsApp.");
      return;
    }
    window.open(whatsappUrl(number, approach.message), "_blank", "noopener");
    registerContact.mutate({ company: approach.company, message: approach.message });
    setApproach(null);
  };


  const filtered = useMemo(
    () =>
      companies.filter((company) => {
        if (filter === "sem_site") return !company.website;
        if (filter === "sem_instagram") return !company.instagram;
        if (filter === "sem_facebook") return !company.facebook;
        if (filter === "sem_redes") return !company.instagram && !company.facebook;
        if (filter === "sem_email") return !company.email;
        if (filter === "parcial") return opportunity(company) === "Presença digital parcial";
        return true;
      }),
    [companies, filter],
  );

  const isAdded = (company: RadarCompany) => existing.some((item) => item.place_id === company.placeId);

  return (
    <div>
      <PageHeader
        title="Radar de Prospecção"
        subtitle="Encontre empresas que podem precisar dos serviços da Agência MT Web."
      />

      <Card className="shadow-card">
        <CardContent className="p-5">
          <form
            className="grid gap-4 md:grid-cols-2 lg:grid-cols-6"
            onSubmit={(event) => {
              event.preventDefault();
              search.mutate();
            }}
          >
            <div className="space-y-2 lg:col-span-2">
              <Label htmlFor="radar-city">Cidade</Label>
              <Input id="radar-city" required value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} placeholder="Rosário Oeste" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="radar-state">Estado</Label>
              <Input id="radar-state" required maxLength={2} value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} />
            </div>
            <div className="space-y-2 lg:col-span-2">
              <Label htmlFor="radar-segment">Segmento</Label>
              <Input id="radar-segment" required value={form.segment} onChange={(e) => setForm({ ...form, segment: e.target.value })} placeholder="Restaurantes" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="radar-count">Quantidade</Label>
              <Select value={form.requested} onValueChange={(value) => setForm({ ...form, requested: value })}>
                <SelectTrigger id="radar-count"><SelectValue /></SelectTrigger>
                <SelectContent>{[5, 10, 15, 20].map((n) => <SelectItem key={n} value={String(n)}>{n}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2 lg:col-span-4">
              <Label htmlFor="radar-keyword">Palavra-chave (opcional)</Label>
              <Input id="radar-keyword" value={form.keyword} onChange={(e) => setForm({ ...form, keyword: e.target.value })} placeholder="delivery, odontologia, roupas..." />
            </div>
            <div className="flex items-end lg:col-span-2">
              <Button type="submit" className="w-full gap-2" disabled={search.isPending}>
                <Search className="size-4" /> {search.isPending ? "Pesquisando..." : "Encontrar empresas"}
              </Button>
            </div>
          </form>
          {usage && <p className="mt-3 text-xs text-muted-foreground">Uso neste mês: {usage.used} de {usage.limit} pesquisas · até {usage.resultLimit} resultados por pesquisa.</p>}
        </CardContent>
      </Card>

      {companies.length > 0 && (
        <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-bold">Empresas encontradas</h2>
            <p className="text-sm text-muted-foreground">{filtered.length} resultado(s) · Fonte: Google Places</p>
          </div>
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-full sm:w-72"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todas</SelectItem>
              <SelectItem value="sem_site">Sem site identificado</SelectItem>
              <SelectItem value="sem_instagram">Sem Instagram identificado</SelectItem>
              <SelectItem value="sem_facebook">Sem Facebook identificado</SelectItem>
              <SelectItem value="sem_redes">Sem redes sociais identificadas</SelectItem>
              <SelectItem value="sem_email">Sem e-mail encontrado</SelectItem>
              <SelectItem value="parcial">Presença digital parcial</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        {filtered.map((company) => (
          <Card key={company.placeId} className="shadow-card">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <CardTitle className="text-lg">{company.name}</CardTitle>
                  <p className="mt-1 text-xs text-muted-foreground">{company.category ?? "Categoria não identificada"}</p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className="rounded-md bg-secondary px-2 py-1 text-xs font-medium">{opportunity(company)}</span>
                  <span className="text-xs text-muted-foreground">{statuses[company.placeId] ?? "Novo"}</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1.5 text-sm text-muted-foreground">
                <p className="flex items-center gap-2"><MapPin className="size-4 shrink-0" /> {[company.city, company.state].filter(Boolean).join(" - ") || "Localização não identificada"}</p>
                <p className="flex items-center gap-2"><Phone className="size-4 shrink-0" /> {company.phone ?? "Telefone não encontrado"}</p>
                <p className="flex items-center gap-2"><Globe2 className="size-4 shrink-0" /> {company.website ? "Site encontrado" : "Site não identificado na pesquisa"}</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" className="gap-1.5" disabled={!toWhatsappNumber(company.phone)} onClick={() => openApproach(company)}>
                  <MessageCircle className="size-4" /> Chamar no WhatsApp
                </Button>
                {company.phone && <Button variant="outline" size="sm" asChild><a href={`tel:${company.phone.replace(/\s/g, "")}`}><Phone className="mr-1 size-3" /> Ligar</a></Button>}
                {company.email && <Button variant="outline" size="sm" asChild><a href={`mailto:${company.email}`}><Mail className="mr-1 size-3" /> E-mail</a></Button>}
                <Button variant="outline" size="sm" onClick={() => setSelected(company)}>Ver detalhes</Button>
                <Button variant="outline" size="sm" disabled={isAdded(company) || addLead.isPending} onClick={() => addLead.mutate(company)}>{isAdded(company) ? "Já está no CRM" : "Adicionar ao CRM"}</Button>
                {company.website && <Button variant="ghost" size="sm" asChild><a href={company.website} target="_blank" rel="noreferrer">Website <ExternalLink className="ml-1 size-3" /></a></Button>}
                {company.instagram && <Button variant="ghost" size="sm" asChild><a href={company.instagram} target="_blank" rel="noreferrer">Instagram <ExternalLink className="ml-1 size-3" /></a></Button>}
                {company.googleMapsUrl && <Button variant="ghost" size="sm" asChild><a href={company.googleMapsUrl} target="_blank" rel="noreferrer">Google Maps <ExternalLink className="ml-1 size-3" /></a></Button>}
              </div>

            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={!!selected} onOpenChange={(open) => !open && setSelected(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle>{selected.name}</DialogTitle>
                <DialogDescription>Dados públicos retornados pelo Google Places em {new Date(selected.searchedAt).toLocaleString("pt-BR")}.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-5 sm:grid-cols-2">
                <div className="space-y-3 text-sm">
                  <p><strong>Categoria:</strong> {selected.category ?? "Não identificada"}</p>
                  <p><strong>Telefone:</strong> {selected.phone ?? "Não encontrado"}</p>
                  <p><strong>E-mail:</strong> Não encontrado nas fontes consultadas</p>
                  <p><strong>Endereço:</strong> {selected.address ?? "Não identificado"}</p>
                  <p><strong>CEP:</strong> {selected.postalCode ?? "Não identificado"}</p>
                  <p><strong>Fonte:</strong> {selected.source}</p>
                </div>
                <Card>
                  <CardContent className="p-4">
                    <Status label="Site" found={!!selected.website} />
                    <Status label="Instagram" found={!!selected.instagram} />
                    <Status label="Facebook" found={!!selected.facebook} />
                    <Status label="E-mail" found={!!selected.email} />
                    <Status label="Telefone" found={!!selected.phone} />
                  </CardContent>
                </Card>
              </div>
              <div className="rounded-md border border-border bg-secondary/50 p-4">
                <p className="flex items-center gap-2 font-semibold"><Target className="size-4 text-primary" /> Oportunidade identificada</p>
                <p className="mt-1 text-sm text-muted-foreground">{opportunity(selected)}</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button className="gap-1.5" disabled={!toWhatsappNumber(selected.phone)} onClick={() => { const company = selected; setSelected(null); openApproach(company); }}>
                  <MessageCircle className="size-4" /> Chamar no WhatsApp
                </Button>
                <Button variant="outline" disabled={isAdded(selected) || addLead.isPending} onClick={() => addLead.mutate(selected)}>{isAdded(selected) ? "Já está no CRM" : "Adicionar ao CRM"}</Button>

                {isAdded(selected) && (
                  <Button variant="outline" asChild>
                    <Link
                      to="/propostas"
                      search={() => {
                        const clientId = existing.find((item) => item.place_id === selected.placeId)?.id;
                        return clientId ? { cliente: clientId } : {};
                      }}
                    >
                      Criar proposta
                    </Link>
                  </Button>
                )}
                <Button variant="ghost" onClick={() => navigate({ to: "/clientes" })}><Building2 className="mr-2 size-4" /> Ver CRM</Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
      <Dialog open={!!approach} onOpenChange={(open) => !open && setApproach(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          {approach && (
            <>
              <DialogHeader>
                <DialogTitle>Mensagem de abordagem</DialogTitle>
                <DialogDescription>
                  Revise e edite antes de abrir o WhatsApp. O envio continua sendo manual, feito por você.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-2">
                <Label htmlFor="wa-template">Modelo de abordagem</Label>
                <Select
                  value={approach.template}
                  onValueChange={(value) =>
                    setApproach({
                      ...approach,
                      template: value as ApproachTemplateId,
                      message: buildApproachMessage(approach.company, value as ApproachTemplateId, repName, form.segment),
                    })
                  }
                >
                  <SelectTrigger id="wa-template"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {APPROACH_TEMPLATES.map((item) => (
                      <SelectItem key={item.id} value={item.id}>{item.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="wa-message">Mensagem</Label>
                <Textarea
                  id="wa-message"
                  rows={12}
                  value={approach.message}
                  onChange={(event) => setApproach({ ...approach, message: event.target.value })}
                />
              </div>
              <DialogFooter className="flex-col gap-2 sm:flex-row">
                <Button variant="ghost" onClick={() => setApproach(null)}>← Voltar</Button>
                <Button
                  variant="outline"
                  className="gap-1.5"
                  onClick={() => {
                    navigator.clipboard.writeText(approach.message).then(
                      () => toast.success("Mensagem copiada."),
                      () => toast.error("Não foi possível copiar a mensagem."),
                    );
                  }}
                >
                  <Copy className="size-4" /> Copiar mensagem
                </Button>
                <Button className="gap-1.5" onClick={openWhatsapp}>
                  <MessageCircle className="size-4" /> Abrir WhatsApp
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );

}