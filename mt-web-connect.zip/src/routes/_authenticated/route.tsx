import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { useSession, useProfile } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/auth" });
    return { user: data.user };
  },
  component: AuthedLayout,
});

function AuthedLayout() {
  const { user } = useSession();
  const { data } = useProfile(user);
  const name = data?.profile?.full_name ?? user?.email ?? "";

  return (
    <AppShell isAdmin={data?.isAdmin ?? false} userName={name.split(" ")[0] ?? ""}>
      <Outlet />
    </AppShell>
  );
}
