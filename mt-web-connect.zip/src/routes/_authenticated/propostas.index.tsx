import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/auth";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { brl, dateBR, labelOf, PROPOSAL_STATUS } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/propostas/")({
  validateSearch: (search: Record<string, unknown>): { cliente?: string } =>
    typeof search["cliente"] === "string" ? { cliente: search["cliente"] } : {},
  head: () => ({
    meta: [
      { title: "Propostas comerciais — Agência MT Web" },
      { name: "description", content: "Crie e acompanhe propostas comerciais para seus clientes." },
      { property: "og:title", content: "Propostas comerciais — Agência MT Web" },
      { property: "og:description", content: "Orçamentos profissionais em poucos cliques." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Propostas,
});

type Item = { service_id: string | null; description: string; quantity: number; unit_price: number };

function Propostas() {
  const { cliente } = Route.useSearch();
  const { user } = useSession();
  const qc = useQueryClient();
  const [open, setOpen] = useState(!!cliente);
  const [clientId, setClientId] = useState(cliente ?? "");
  const [title, setTitle] = useState("");
  const [discount, setDiscount] = useState("0");
  const [validUntil, setValidUntil] = useState("");
  const [terms, setTerms] = useState("50% na assinatura e 50% na entrega");
  const [notes, setNotes] = useState("");
  const [items, setItems] = useState<Item[]>([]);

  const { data: clients = [] } = useQuery({
    queryKey: ["clients", user?.id],
    enabled: !!user,
    queryFn: async () => (await supabase.from("clients").select("id, company_name")).data ?? [],
  });
  const { data: services = [] } = useQuery({
    queryKey: ["services"],
    queryFn: async () =>
      (await supabase.from("services").select("*").eq("active", true).order("name")).data ?? [],
  });
  const { data: proposals = [] } = useQuery({
    queryKey: ["proposals", user?.id],
    enabled: !!user,
    queryFn: async () =>
      (
        await supabase
          .from("proposals")
          .select("*, clients(company_name)")
          .order("created_at", { ascending: false })
      ).data ?? [],
  });

  const subtotal = items.reduce((s, i) => s + i.quantity * i.unit_price, 0);
  const total = Math.max(0, subtotal - Number(discount || 0));

  const create = useMutation({
    mutationFn: async () => {
      if (!clientId) throw new Error("Selecione o cliente.");
      if (items.length === 0) throw new Error("Adicione pelo menos um serviço.");
      const { data, error } = await supabase
        .from("proposals")
        .insert({
          owner_id: user!.id,
          client_id: clientId,
          title,
          discount: Number(discount || 0),
          total,
          payment_terms: terms,
          valid_until: validUntil || null,
          notes,
        })
        .select()
        .single();
      if (error) throw error;
      const { error: itemsError } = await supabase.from("proposal_items").insert(
        items.map((i) => ({
          owner_id: user!.id,
          proposal_id: data.id,
          service_id: i.service_id,
          description: i.description,
          quantity: i.quantity,
          unit_price: i.unit_price,
        })),
      );
      if (itemsError) throw itemsError;
    },
    onSuccess: () => {
      toast.success("Proposta criada.");
      setOpen(false);
      setItems([]);
      setTitle("");
      setDiscount("0");
      qc.invalidateQueries({ queryKey: ["proposals"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const setStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("proposals").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["proposals"] }),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("proposals").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["proposals"] }),
  });

  function addService(serviceId: string) {
    const s = services.find((x) => x.id === serviceId);
    if (!s) return;
    setItems([
      ...items,
      {
        service_id: s.id,
        description: s.name,
        quantity: 1,
        unit_price: Number(s.suggested_price),
      },
    ]);
  }

  return (
    <div>
      <PageHeader
        title="Propostas comerciais"
        subtitle="Monte orçamentos com os serviços do catálogo."
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="size-4" /> Nova proposta
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-2xl">
              <DialogHeader>
                <DialogTitle>Nova proposta</DialogTitle>
              </DialogHeader>
              <form
                className="space-y-4"
                onSubmit={(e) => {
                  e.preventDefault();
                  create.mutate();
                }}
              >
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Cliente</Label>
                    <Select value={clientId} onValueChange={setClientId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {clients.map((c) => (
                          <SelectItem key={c.id} value={c.id}>
                            {c.company_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="title">Título</Label>
                    <Input
                      id="title"
                      required
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="Presença digital completa"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Adicionar serviço</Label>
                  <Select value="" onValueChange={addService}>
                    <SelectTrigger>
                      <SelectValue placeholder="Escolha um serviço do catálogo" />
                    </SelectTrigger>
                    <SelectContent>
                      {services.map((s) => (
                        <SelectItem key={s.id} value={s.id}>
                          {s.name} — {brl(s.suggested_price)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {items.map((i, idx) => (
                  <div key={idx} className="grid grid-cols-12 items-end gap-2">
                    <div className="col-span-6 space-y-1">
                      <Label className="text-xs">Serviço</Label>
                      <Input
                        value={i.description}
                        onChange={(e) => {
                          const copy = [...items];
                          copy[idx] = { ...i, description: e.target.value };
                          setItems(copy);
                        }}
                      />
                    </div>
                    <div className="col-span-2 space-y-1">
                      <Label className="text-xs">Qtd</Label>
                      <Input
                        type="number"
                        min={1}
                        value={i.quantity}
                        onChange={(e) => {
                          const copy = [...items];
                          copy[idx] = { ...i, quantity: Number(e.target.value) };
                          setItems(copy);
                        }}
                      />
                    </div>
                    <div className="col-span-3 space-y-1">
                      <Label className="text-xs">Valor</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={i.unit_price}
                        onChange={(e) => {
                          const copy = [...items];
                          copy[idx] = { ...i, unit_price: Number(e.target.value) };
                          setItems(copy);
                        }}
                      />
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => setItems(items.filter((_, n) => n !== idx))}
                    >
                      <Trash2 className="size-4 text-destructive" />
                    </Button>
                  </div>
                ))}

                <div className="grid gap-4 sm:grid-cols-3">
                  <div className="space-y-2">
                    <Label htmlFor="discount">Desconto</Label>
                    <Input
                      id="discount"
                      type="number"
                      step="0.01"
                      value={discount}
                      onChange={(e) => setDiscount(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="valid">Validade</Label>
                    <Input
                      id="valid"
                      type="date"
                      value={validUntil}
                      onChange={(e) => setValidUntil(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Total</Label>
                    <p className="pt-2 text-lg font-bold text-primary">{brl(total)}</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="terms">Condições de pagamento</Label>
                  <Input id="terms" value={terms} onChange={(e) => setTerms(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notes">Observações</Label>
                  <Textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} />
                </div>
                <Button type="submit" className="w-full" disabled={create.isPending}>
                  Criar proposta
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="grid gap-3">
        {proposals.map((p) => (
          <Card key={p.id} className="shadow-card">
            <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
              <div>
                <p className="font-semibold">{p.title}</p>
                <p className="text-sm text-muted-foreground">
                  {p.clients?.company_name ?? "Sem cliente"} · {brl(p.total)} · validade{" "}
                  {dateBR(p.valid_until)}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Select
                  value={p.status}
                  onValueChange={(v) => setStatus.mutate({ id: p.id, status: v })}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue>{labelOf(PROPOSAL_STATUS, p.status)}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    {PROPOSAL_STATUS.map((s) => (
                      <SelectItem key={s.value} value={s.value}>
                        {s.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button variant="outline" asChild>
                  <Link to="/propostas/$id" params={{ id: p.id }}>
                    Ver
                  </Link>
                </Button>
                <Button variant="ghost" size="icon" onClick={() => remove.mutate(p.id)}>
                  <Trash2 className="size-4 text-destructive" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {proposals.length === 0 && (
          <p className="text-sm text-muted-foreground">Nenhuma proposta criada ainda.</p>
        )}
      </div>
    </div>
  );
}
