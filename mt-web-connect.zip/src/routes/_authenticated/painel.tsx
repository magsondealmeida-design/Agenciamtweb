import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Users, FileText, FolderKanban, Sparkles, Search, Target, Bell, MessageCircle } from "lucide-react";
import { toWhatsappNumber, whatsappUrl } from "@/lib/whatsapp";
import { supabase } from "@/integrations/supabase/client";
import { useSession, useProfile } from "@/lib/auth";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { brl, dateBR, labelOf, STAGES } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/painel")({
  head: () => ({
    meta: [
      { title: "Meu painel — Agência MT Web" },
      { name: "description", content: "Acompanhe clientes, propostas, projetos e receitas." },
      { property: "og:title", content: "Meu painel — Agência MT Web" },
      { property: "og:description", content: "Visão geral do seu negócio digital." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Painel,
});

function Painel() {
  const { user } = useSession();
  const { data: me } = useProfile(user);

  const { data } = useQuery({
    queryKey: ["dashboard", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const [clients, proposals, projects, finance, searches] = await Promise.all([
        supabase.from("clients").select("*").eq("owner_id", user!.id),
        supabase.from("proposals").select("*").eq("owner_id", user!.id),
        supabase.from("projects").select("*, clients(company_name)").eq("owner_id", user!.id),
        supabase.from("financial_transactions").select("*").eq("owner_id", user!.id),
        supabase.from("prospect_searches").select("results_count").eq("owner_id", user!.id),
      ]);
      return {
        clients: clients.data ?? [],
        proposals: proposals.data ?? [],
        projects: projects.data ?? [],
        finance: finance.data ?? [],
        searches: searches.data ?? [],
      };
    },
  });

  const clients = data?.clients ?? [];
  const proposals = data?.proposals ?? [];
  const projects = data?.projects ?? [];
  const finance = data?.finance ?? [];
  const searches = data?.searches ?? [];
  const radarLeads = clients.filter((client) => client.source?.startsWith("Radar"));
  const radarClientIds = new Set(radarLeads.map((client) => client.id));
  const radarProposals = proposals.filter((proposal) => proposal.client_id && radarClientIds.has(proposal.client_id));
  const foundCompanies = searches.reduce((sum, search) => sum + search.results_count, 0);

  const followUps = (clients as unknown as Array<{ id: string; company_name: string; phone: string | null; next_action_at: string | null }>).filter(
    (c) => !!c.next_action_at,
  );
  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);
  const endOfToday = new Date(startOfToday.getTime() + 86400000);
  const atrasados = followUps.filter((c) => new Date(c.next_action_at!) < startOfToday);
  const hoje = followUps.filter(
    (c) => new Date(c.next_action_at!) >= startOfToday && new Date(c.next_action_at!) < endOfToday,
  );
  const futuros = followUps.filter((c) => new Date(c.next_action_at!) >= endOfToday);
  const emNegociacao = clients.filter((c) => ["em_conversa", "interessado", "negociacao", "reuniao"].includes(c.stage));
  const aguardandoRetorno = proposals.filter((p) => p.status === "enviada");

  const now = new Date();
  const monthKey = (d: string) => d.slice(0, 7);
  const currentMonth = now.toISOString().slice(0, 7);

  const receitaMes = finance
    .filter((t) => t.kind === "receita" && monthKey(t.entry_date) === currentMonth)
    .reduce((s, t) => s + Number(t.amount), 0);
  const aReceber = finance
    .filter((t) => t.kind === "receita" && t.status === "pendente")
    .reduce((s, t) => s + Number(t.amount), 0);

  const chart = Array.from({ length: 6 }).map((_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
    const key = d.toISOString().slice(0, 7);
    return {
      mes: d.toLocaleDateString("pt-BR", { month: "short" }),
      receita: finance
        .filter((t) => t.kind === "receita" && monthKey(t.entry_date) === key)
        .reduce((s, t) => s + Number(t.amount), 0),
    };
  });

  const sub = me?.subscription as { status?: string; subscription_plans?: { name?: string } } | null;

  return (
    <div>
      <PageHeader
        title={`Olá, ${(me?.profile?.full_name ?? "representante").split(" ")[0]}!`}
        subtitle={
          sub?.subscription_plans?.name
            ? `Plano ${sub.subscription_plans.name} · assinatura ${sub.status}`
            : "Assinatura ainda não ativada pela administração"
        }
        action={
          <div className="flex gap-2">
            <Button asChild variant="outline">
              <Link to="/clientes">Novo cliente</Link>
            </Button>
            <Button asChild>
              <Link to="/propostas" search={{}}>Nova proposta</Link>
            </Button>
          </div>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Clientes e leads" value={clients.length} />
        <StatCard
          label="Projetos ativos"
          value={projects.filter((p) => !["concluido", "cancelado"].includes(p.status)).length}
        />
        <StatCard
          label="Propostas enviadas"
          value={proposals.filter((p) => p.status !== "rascunho").length}
          hint={`${proposals.filter((p) => p.status === "aceita").length} aceitas`}
        />
        <StatCard label="Receita do mês" value={brl(receitaMes)} hint={`A receber ${brl(aReceber)}`} />
      </div>

      <Card className="mt-6 shadow-card">
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <div>
            <CardTitle className="flex items-center gap-2"><Target className="size-5 text-primary" /> Radar de Prospecção</CardTitle>
            <p className="mt-1 text-sm text-muted-foreground">Transforme empresas encontradas em oportunidades comerciais.</p>
          </div>
          <Button asChild><Link to="/radar"><Search className="mr-2 size-4" /> Encontrar novos clientes</Link></Button>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <StatCard label="Empresas encontradas" value={foundCompanies} />
          <StatCard label="Oportunidades" value={foundCompanies} />
          <StatCard label="Leads adicionados" value={radarLeads.length} />
          <StatCard label="Propostas geradas" value={radarProposals.length} />
          <StatCard label="Clientes conquistados" value={radarLeads.filter((client) => client.stage === "ganho").length} />
        </CardContent>
      </Card>

      <Card className="mt-6 shadow-card">
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <CardTitle className="flex items-center gap-2">
            <Bell className="size-5 text-primary" /> Follow-ups
          </CardTitle>
          <Button asChild variant="outline">
            <Link to="/clientes">Abrir clientes e leads</Link>
          </Button>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="🔴 Atrasados" value={atrasados.length} />
          <StatCard label="🟡 Para hoje" value={hoje.length} />
          <StatCard label="🟢 Futuros" value={futuros.length} />
          <StatCard
            label="Negociações em andamento"
            value={emNegociacao.length}
            hint={`${aguardandoRetorno.length} propostas aguardando retorno`}
          />
          <div className="sm:col-span-2 lg:col-span-4 space-y-2 text-sm">
            {[...atrasados, ...hoje].slice(0, 5).map((c) => (
              <div key={c.id} className="flex flex-wrap items-center justify-between gap-2 border-b border-border pb-2 last:border-0">
                <span>
                  {c.company_name} — {new Date(c.next_action_at!).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" })}
                </span>
                {toWhatsappNumber(c.phone) && (
                  <Button size="sm" variant="outline" asChild>
                    <a href={whatsappUrl(toWhatsappNumber(c.phone)!, "")} target="_blank" rel="noreferrer">
                      <MessageCircle className="mr-1 size-3" /> Abrir WhatsApp
                    </a>
                  </Button>
                )}
              </div>
            ))}
            {atrasados.length + hoje.length === 0 && (
              <p className="text-muted-foreground">Nenhum follow-up para hoje.</p>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card className="shadow-card lg:col-span-2">
          <CardHeader>
            <CardTitle>Receita dos últimos 6 meses</CardTitle>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="mes" tickLine={false} axisLine={false} />
                <YAxis tickLine={false} axisLine={false} width={70} />
                <Tooltip formatter={(v: number) => brl(v)} />
                <Bar dataKey="receita" fill="var(--color-primary)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>Atalhos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button variant="outline" className="w-full justify-start gap-2" asChild>
              <Link to="/clientes">
                <Users className="size-4" /> Prospectar e cadastrar cliente
              </Link>
            </Button>
            <Button variant="outline" className="w-full justify-start gap-2" asChild>
              <Link to="/propostas" search={{}}>
                <FileText className="size-4" /> Criar proposta comercial
              </Link>
            </Button>
            <Button variant="outline" className="w-full justify-start gap-2" asChild>
              <Link to="/projetos">
                <FolderKanban className="size-4" /> Acompanhar projetos
              </Link>
            </Button>
            <p className="flex items-start gap-2 pt-2 text-xs text-muted-foreground">
              <Sparkles className="mt-0.5 size-4 shrink-0" />
              Radar de Oportunidades, gerador de sites e conteúdos chegam na próxima etapa.
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="mt-6 shadow-card">
        <CardHeader>
          <CardTitle>Atividades recentes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          {clients.slice(0, 5).map((c) => (
            <div key={c.id} className="flex justify-between border-b border-border pb-2 last:border-0">
              <span>{c.company_name}</span>
              <span className="text-muted-foreground">
                {labelOf(STAGES, c.stage)} · {dateBR(c.created_at.slice(0, 10))}
              </span>
            </div>
          ))}
          {clients.length === 0 && (
            <p className="text-muted-foreground">Nenhum cliente cadastrado ainda.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
