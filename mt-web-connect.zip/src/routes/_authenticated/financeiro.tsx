import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/auth";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { brl, dateBR } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/financeiro")({
  head: () => ({
    meta: [
      { title: "Financeiro — Agência MT Web" },
      { name: "description", content: "Controle receitas, despesas, comissões e contas a receber." },
      { property: "og:title", content: "Financeiro — Agência MT Web" },
      { property: "og:description", content: "Controle financeiro do representante." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Financeiro,
});

const EMPTY = {
  description: "",
  kind: "receita",
  amount: "0",
  entry_date: new Date().toISOString().slice(0, 10),
  category: "",
  status: "pendente",
  client_id: "",
};

function Financeiro() {
  const { user } = useSession();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY);

  const { data: clients = [] } = useQuery({
    queryKey: ["clients", user?.id],
    enabled: !!user,
    queryFn: async () => (await supabase.from("clients").select("id, company_name")).data ?? [],
  });

  const { data: rows = [] } = useQuery({
    queryKey: ["finance", user?.id],
    enabled: !!user,
    queryFn: async () =>
      (
        await supabase
          .from("financial_transactions")
          .select("*, clients(company_name)")
          .order("entry_date", { ascending: false })
      ).data ?? [],
  });

  const create = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("financial_transactions").insert({
        owner_id: user!.id,
        description: form.description,
        kind: form.kind,
        amount: Number(form.amount || 0),
        entry_date: form.entry_date,
        category: form.category,
        status: form.status,
        client_id: form.client_id || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Lançamento registrado.");
      setForm(EMPTY);
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["finance"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("financial_transactions").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["finance"] }),
  });

  const receitas = rows.filter((r) => r.kind === "receita");
  const despesas = rows.filter((r) => r.kind === "despesa");
  const comissoes = rows.filter((r) => r.kind === "comissao");
  const total = (list: typeof rows) => list.reduce((s, r) => s + Number(r.amount), 0);
  const resultado = total(receitas) - total(despesas) - total(comissoes);

  return (
    <div>
      <PageHeader
        title="Financeiro"
        subtitle="Receita bruta não é lucro: considere despesas e comissões no resultado."
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="size-4" /> Novo lançamento
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Novo lançamento</DialogTitle>
              </DialogHeader>
              <form
                className="space-y-4"
                onSubmit={(e) => {
                  e.preventDefault();
                  create.mutate();
                }}
              >
                <div className="space-y-2">
                  <Label htmlFor="desc">Descrição</Label>
                  <Input
                    id="desc"
                    required
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                  />
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Tipo</Label>
                    <Select value={form.kind} onValueChange={(v) => setForm({ ...form, kind: v })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="receita">Receita</SelectItem>
                        <SelectItem value="despesa">Despesa</SelectItem>
                        <SelectItem value="comissao">Comissão a pagar</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="value">Valor</Label>
                    <Input
                      id="value"
                      type="number"
                      step="0.01"
                      value={form.amount}
                      onChange={(e) => setForm({ ...form, amount: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="date">Data</Label>
                    <Input
                      id="date"
                      type="date"
                      value={form.entry_date}
                      onChange={(e) => setForm({ ...form, entry_date: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cat">Categoria</Label>
                    <Input
                      id="cat"
                      value={form.category}
                      onChange={(e) => setForm({ ...form, category: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Status</Label>
                    <Select
                      value={form.status}
                      onValueChange={(v) => setForm({ ...form, status: v })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pendente">Pendente</SelectItem>
                        <SelectItem value="pago">Pago / recebido</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Cliente</Label>
                    <Select
                      value={form.client_id}
                      onValueChange={(v) => setForm({ ...form, client_id: v })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Opcional" />
                      </SelectTrigger>
                      <SelectContent>
                        {clients.map((c) => (
                          <SelectItem key={c.id} value={c.id}>
                            {c.company_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button type="submit" className="w-full">
                  Salvar lançamento
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Receita bruta" value={brl(total(receitas))} />
        <StatCard label="Despesas" value={brl(total(despesas))} />
        <StatCard label="Comissões" value={brl(total(comissoes))} />
        <StatCard
          label="Resultado estimado"
          value={brl(resultado)}
          hint="Receitas menos despesas e comissões"
        />
      </div>

      <div className="mt-6 grid gap-3">
        {rows.map((r) => (
          <Card key={r.id} className="shadow-card">
            <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
              <div>
                <p className="font-medium">{r.description}</p>
                <p className="text-xs text-muted-foreground">
                  {dateBR(r.entry_date)} · {r.category || "Sem categoria"} ·{" "}
                  {r.clients?.company_name ?? "Sem cliente"} · {r.status}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span
                  className={
                    r.kind === "receita" ? "font-semibold text-accent" : "font-semibold text-destructive"
                  }
                >
                  {r.kind === "receita" ? "+" : "-"} {brl(r.amount)}
                </span>
                <Button variant="ghost" size="icon" onClick={() => remove.mutate(r.id)}>
                  <Trash2 className="size-4 text-destructive" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {rows.length === 0 && (
          <p className="text-sm text-muted-foreground">Nenhum lançamento registrado.</p>
        )}
      </div>
    </div>
  );
}
