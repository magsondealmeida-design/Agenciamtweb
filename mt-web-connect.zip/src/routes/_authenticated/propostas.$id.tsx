import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Printer, ArrowLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useSession, useProfile } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { brl, dateBR, labelOf, PROPOSAL_STATUS } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/propostas/$id")({
  head: () => ({
    meta: [
      { title: "Proposta comercial — Agência MT Web" },
      { name: "description", content: "Visualize e imprima a proposta comercial do seu cliente." },
      { property: "og:title", content: "Proposta comercial — Agência MT Web" },
      { property: "og:description", content: "Proposta profissional da Agência MT Web." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PropostaDetalhe,
});

function PropostaDetalhe() {
  const { id } = Route.useParams();
  const { user } = useSession();
  const { data: me } = useProfile(user);

  const { data } = useQuery({
    queryKey: ["proposal", id],
    queryFn: async () => {
      const [{ data: proposal }, { data: items }] = await Promise.all([
        supabase.from("proposals").select("*, clients(*)").eq("id", id).maybeSingle(),
        supabase.from("proposal_items").select("*").eq("proposal_id", id),
      ]);
      return { proposal, items: items ?? [] };
    },
  });

  const p = data?.proposal;
  const items = data?.items ?? [];
  const subtotal = items.reduce((s, i) => s + Number(i.unit_price) * i.quantity, 0);

  if (!p) return <p className="text-sm text-muted-foreground">Carregando proposta...</p>;

  return (
    <div>
      <div className="mb-4 flex items-center justify-between print:hidden">
        <Button variant="ghost" className="gap-2" asChild>
          <Link to="/propostas" search={{}}>
            <ArrowLeft className="size-4" /> Voltar
          </Link>
        </Button>
        <Button className="gap-2" onClick={() => window.print()}>
          <Printer className="size-4" /> Imprimir / salvar PDF
        </Button>
      </div>

      <div className="rounded-xl border border-border bg-card p-8 shadow-card print:border-0 print:shadow-none">
        <div className="flex items-start justify-between border-b border-border pb-6">
          <div>
            <p className="text-lg font-extrabold text-primary">Agência MT Web</p>
            <p className="text-xs text-muted-foreground">
              Sua agência digital. Seu negócio. Seu crescimento.
            </p>
          </div>
          <div className="text-right text-sm">
            <p className="font-semibold">Proposta comercial</p>
            <p className="text-muted-foreground">{dateBR(p.created_at.slice(0, 10))}</p>
            <p className="text-muted-foreground">{labelOf(PROPOSAL_STATUS, p.status)}</p>
          </div>
        </div>

        <div className="grid gap-6 py-6 sm:grid-cols-2">
          <div>
            <p className="text-xs uppercase text-muted-foreground">Cliente</p>
            <p className="font-semibold">{p.clients?.company_name ?? "—"}</p>
            <p className="text-sm text-muted-foreground">{p.clients?.contact_name}</p>
            <p className="text-sm text-muted-foreground">
              {[p.clients?.phone, p.clients?.email].filter(Boolean).join(" · ")}
            </p>
          </div>
          <div className="sm:text-right">
            <p className="text-xs uppercase text-muted-foreground">Representante</p>
            <p className="font-semibold">{me?.profile?.full_name ?? user?.email}</p>
            <p className="text-sm text-muted-foreground">{me?.profile?.phone}</p>
          </div>
        </div>

        <h2 className="text-xl font-bold">{p.title}</h2>

        <table className="mt-4 w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-muted-foreground">
              <th className="py-2">Serviço</th>
              <th className="py-2 text-center">Qtd</th>
              <th className="py-2 text-right">Valor unit.</th>
              <th className="py-2 text-right">Total</th>
            </tr>
          </thead>
          <tbody>
            {items.map((i) => (
              <tr key={i.id} className="border-b border-border/60">
                <td className="py-2">{i.description}</td>
                <td className="py-2 text-center">{i.quantity}</td>
                <td className="py-2 text-right">{brl(i.unit_price)}</td>
                <td className="py-2 text-right">{brl(Number(i.unit_price) * i.quantity)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="mt-4 space-y-1 text-right text-sm">
          <p>Subtotal: {brl(subtotal)}</p>
          <p>Desconto: {brl(p.discount)}</p>
          <p className="text-lg font-bold text-primary">Total: {brl(p.total)}</p>
        </div>

        <div className="mt-6 space-y-2 border-t border-border pt-6 text-sm text-muted-foreground">
          <p>
            <strong className="text-foreground">Condições de pagamento:</strong> {p.payment_terms}
          </p>
          <p>
            <strong className="text-foreground">Validade da proposta:</strong>{" "}
            {dateBR(p.valid_until)}
          </p>
          {p.notes && (
            <p>
              <strong className="text-foreground">Observações:</strong> {p.notes}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
