import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowRight,
  BarChart3,
  Bot,
  CheckCircle2,
  Check,
  FileText,
  Globe,
  GraduationCap,
  LineChart,
  MapPin,
  Search,
  Sparkles,
  Target,
  Users,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { brl } from "@/lib/format";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Agência MT Web — Sua agência digital. Seu negócio." },
      {
        name: "description",
        content:
          "Venda sites, landing pages, SEO local, conteúdo e automação para empresas da sua região — com CRM, propostas, projetos e financeiro em um só lugar.",
      },
      { property: "og:title", content: "Agência MT Web — Sua agência digital" },
      {
        property: "og:description",
        content:
          "Ecossistema de agência digital para representantes: CRM, propostas, projetos e controle financeiro.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const ECOSYSTEM = [
  {
    icon: Users,
    title: "Para representantes",
    text: "Área de trabalho completa para prospectar, vender e entregar serviços digitais com a sua marca pessoal.",
  },
  {
    icon: LineChart,
    title: "Para o seu faturamento",
    text: "Controle de receitas, despesas, contas a receber e comissões com visão mensal clara.",
  },
  {
    icon: GraduationCap,
    title: "Para quem indica",
    text: "Cada conta recebe um código de indicação para divulgar o ecossistema e crescer em rede.",
  },
];

const SERVICES = [
  { icon: Globe, title: "Sites institucionais", text: "Presença digital profissional para empresas locais." },
  { icon: FileText, title: "Landing pages", text: "Páginas de alta conversão para campanhas." },
  { icon: Search, title: "SEO local", text: "Ser encontrado por quem busca na cidade." },
  { icon: MapPin, title: "Google Business", text: "Perfil da empresa otimizado no Google Maps." },
  { icon: Sparkles, title: "Conteúdo e artes", text: "Pacotes mensais para redes sociais." },
  { icon: Bot, title: "Automação de atendimento", text: "Fluxos de WhatsApp e funis de venda." },
];

const STEPS = [
  { n: "01", title: "Assine um plano", text: "Escolha o plano que cabe no seu momento e ative sua área de trabalho." },
  { n: "02", title: "Prospecte empresas", text: "Cadastre leads no CRM e acompanhe o funil de vendas." },
  { n: "03", title: "Envie propostas", text: "Monte orçamentos profissionais com o catálogo da agência." },
  { n: "04", title: "Entregue e fature", text: "Gerencie projetos e controle receitas, despesas e comissões." },
];

const TOOLS = [
  "CRM com funil de vendas",
  "Catálogo de serviços pronto para vender",
  "Gerador de propostas com impressão",
  "Gestão de projetos em lista e Kanban",
  "Controle financeiro por representante",
  "Painel administrativo completo",
];

const FAQ = [
  {
    q: "Preciso saber programar para ser representante?",
    a: "Não. A plataforma entrega o catálogo de serviços, as propostas e a gestão dos projetos prontos. A execução técnica é organizada pela administração da Agência MT Web.",
  },
  {
    q: "Como funciona a assinatura?",
    a: "Você escolhe um plano e a administração ativa a assinatura manualmente nesta versão. A cobrança recorrente automática entra quando o gateway de pagamento for configurado.",
  },
  {
    q: "Meus clientes ficam visíveis para outros representantes?",
    a: "Não. Cada representante enxerga apenas os próprios clientes, propostas, projetos e lançamentos financeiros. O isolamento é aplicado no banco de dados.",
  },
  {
    q: "Existe programa de afiliados?",
    a: "Sim, cada conta recebe um código de indicação. O painel de cliques, conversões e saques está previsto para a próxima fase, e nenhuma comissão é liberada sem pagamento confirmado.",
  },
];

const COMMISSION: Record<string, string> = {
  Starter: "Comissão de até 25% por venda",
  Pro: "Comissão de até 35% por venda",
  Master: "Comissão de até 45% por venda",
};

function Logo() {
  return (
    <span className="flex items-center gap-2">
      <span className="grid size-9 place-items-center rounded-xl bg-hero-gradient text-primary-foreground">
        <BarChart3 className="size-5" />
      </span>
      <span className="text-lg font-extrabold tracking-tight">
        Agência <span className="text-accent">MT Web</span>
      </span>
    </span>
  );
}

function Landing() {
  const { data: plans } = useQuery({
    queryKey: ["public-plans"],
    queryFn: async () => {
      const { data } = await supabase
        .from("subscription_plans")
        .select("*")
        .eq("active", true)
        .order("price_monthly");
      return data ?? [];
    },
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <Link to="/">
            <Logo />
          </Link>
          <nav className="hidden items-center gap-7 text-sm text-muted-foreground md:flex">
            <a href="#ecossistema" className="hover:text-foreground">Ecossistema</a>
            <a href="#servicos" className="hover:text-foreground">Serviços</a>
            <a href="#como-funciona" className="hover:text-foreground">Como funciona</a>
            <a href="#planos" className="hover:text-foreground">Planos</a>
            <a href="#faq" className="hover:text-foreground">FAQ</a>
          </nav>
          <div className="flex items-center gap-3">
            <Link to="/auth" search={{ modo: "login" }} className="text-sm hover:underline">
              Entrar
            </Link>
            <Button asChild size="sm">
              <Link to="/auth" search={{ modo: "cadastro" }}>Quero ser representante</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="bg-soft-gradient">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-4 py-20 lg:grid-cols-2">
          <div>
            <span className="inline-flex rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
              Ecossistema de agência digital para representantes
            </span>
            <h1 className="mt-6 text-4xl font-extrabold leading-tight tracking-tight md:text-5xl">
              Sua agência digital.
              <br />
              Seu negócio. <span className="text-primary">Seu crescimento.</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg text-muted-foreground">
              Venda sites, landing pages, SEO local, conteúdo e automação para empresas da sua
              região — com CRM, propostas, projetos e financeiro em um só lugar.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Button asChild size="lg">
                <Link to="/auth" search={{ modo: "cadastro" }}>
                  Quero ser representante <ArrowRight className="ml-1 size-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="secondary">
                <a href="#planos">Conhecer os planos</a>
              </Button>
              <Button asChild size="lg" variant="ghost" className="text-primary">
                <a href="#afiliados">Quero ser afiliado</a>
              </Button>
            </div>
            <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted-foreground">
              {["Sem taxa de adesão", "Comissões de 25% a 45%", "Cancele quando quiser"].map((i) => (
                <li key={i} className="flex items-center gap-2">
                  <CheckCircle2 className="size-4 text-accent" /> {i}
                </li>
              ))}
            </ul>
          </div>

          {/* Painel ilustrativo */}
          <div className="rounded-3xl border bg-card p-6 shadow-card">
            <p className="text-xs font-semibold tracking-[0.2em] text-muted-foreground">
              PAINEL DO REPRESENTANTE
            </p>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {[
                { l: "Receita do mês", v: "R$ 14.400", c: "text-primary" },
                { l: "Comissões previstas", v: "R$ 4.320", c: "text-accent" },
                { l: "Clientes ativos", v: "18", c: "" },
                { l: "Projetos em curso", v: "7", c: "" },
              ].map((s) => (
                <div key={s.l} className="rounded-2xl border bg-background p-4">
                  <p className="text-xs text-muted-foreground">{s.l}</p>
                  <p className={`mt-1 text-2xl font-bold ${s.c}`}>{s.v}</p>
                </div>
              ))}
            </div>
            <div className="mt-3 flex h-28 items-end gap-3 rounded-2xl border bg-background p-4">
              {[40, 55, 52, 70, 82, 96].map((h, i) => (
                <div
                  key={i}
                  className="flex-1 rounded-t-md bg-hero-gradient"
                  style={{ height: `${h}%` }}
                />
              ))}
            </div>
            <p className="mt-3 text-center text-xs text-muted-foreground">
              Números ilustrativos de demonstração.
            </p>
          </div>
        </div>
      </section>

      {/* Ecossistema */}
      <section id="ecossistema" className="mx-auto max-w-6xl px-4 py-20">
        <p className="text-xs font-semibold tracking-[0.2em] text-accent">O ECOSSISTEMA</p>
        <h2 className="mt-3 text-3xl font-bold tracking-tight md:text-4xl">
          Uma agência inteira dentro do seu navegador
        </h2>
        <p className="mt-3 max-w-2xl text-muted-foreground">
          A Agência MT Web entrega a estrutura comercial e operacional. Você entrega o
          relacionamento — e fica com a comissão de cada serviço vendido.
        </p>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {ECOSYSTEM.map((e) => (
            <div key={e.title} className="rounded-2xl border bg-card p-6 shadow-card">
              <span className="grid size-11 place-items-center rounded-xl bg-primary/10 text-primary">
                <e.icon className="size-5" />
              </span>
              <h3 className="mt-5 text-lg font-semibold">{e.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{e.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Serviços */}
      <section id="servicos" className="border-y bg-muted/40">
        <div className="mx-auto max-w-6xl px-4 py-20">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">
            Serviços que você pode vender hoje
          </h2>
          <p className="mt-3 max-w-2xl text-muted-foreground">
            Catálogo pronto, com preço sugerido, prazo estimado e percentual de comissão definido
            pela administração.
          </p>
          <div className="mt-10 grid gap-5 md:grid-cols-3">
            {SERVICES.map((s) => (
              <div key={s.title} className="rounded-2xl border bg-card p-6 shadow-card">
                <s.icon className="size-6 text-accent" />
                <h3 className="mt-4 font-semibold">{s.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{s.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Como funciona */}
      <section id="como-funciona" className="mx-auto max-w-6xl px-4 py-20">
        <h2 className="text-3xl font-bold tracking-tight md:text-4xl">Como funciona</h2>
        <div className="mt-10 grid gap-6 md:grid-cols-4">
          {STEPS.map((s) => (
            <div key={s.n} className="rounded-2xl border bg-card p-6 shadow-card">
              <span className="text-2xl font-extrabold text-primary/30">{s.n}</span>
              <h3 className="mt-3 font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Ferramentas */}
      <section className="border-y bg-muted/40">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-20 md:grid-cols-2">
          <div>
            <p className="text-xs font-semibold tracking-[0.2em] text-accent">FERRAMENTAS INCLUSAS</p>
            <h2 className="mt-3 text-3xl font-bold tracking-tight md:text-4xl">
              Tudo o que uma agência precisa, sem equipe grande
            </h2>
            <p className="mt-3 text-muted-foreground">
              Recursos de prospecção avançada, gerador de sites, gerador de conteúdo com IA e
              calendário editorial estão previstos para as próximas fases.
            </p>
          </div>
          <ul className="grid gap-3 self-center">
            {TOOLS.map((t) => (
              <li key={t} className="flex items-center gap-3 rounded-xl border bg-card px-4 py-3">
                <Check className="size-4 shrink-0 text-accent" />
                <span className="text-sm">{t}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Planos */}
      <section id="planos" className="mx-auto max-w-6xl px-4 py-20">
        <h2 className="text-3xl font-bold tracking-tight md:text-4xl">Planos de assinatura</h2>
        <p className="mt-3 max-w-2xl text-muted-foreground">
          Assinaturas ativadas manualmente pela administração nesta versão. A cobrança recorrente
          entra quando o gateway de pagamento for configurado.
        </p>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {(plans ?? []).map((p, i) => {
            const featured = i === 1;
            const features: string[] = Array.isArray(p.features) ? (p.features as string[]) : [];
            return (
              <div
                key={p.id}
                className={`relative rounded-2xl border bg-card p-6 shadow-card ${
                  featured ? "border-primary ring-1 ring-primary" : ""
                }`}
              >
                {featured && (
                  <span className="absolute -top-3 left-6 rounded-full bg-primary px-3 py-1 text-xs font-medium text-primary-foreground">
                    Mais escolhido
                  </span>
                )}
                <h3 className="text-lg font-semibold">{p.name}</h3>
                <p className="mt-3">
                  <span className="text-3xl font-extrabold text-primary">{brl(p.price_monthly)}</span>
                  <span className="text-sm text-muted-foreground">/mês</span>
                </p>
                <p className="mt-1 text-sm text-accent">{COMMISSION[p.name] ?? p.description}</p>
                <ul className="mt-5 space-y-2 text-sm">
                  {features.map((f) => (
                    <li key={f} className="flex items-center gap-2">
                      <Check className="size-4 text-accent" /> {f}
                    </li>
                  ))}
                  {p.max_clients ? (
                    <li className="flex items-center gap-2">
                      <Check className="size-4 text-accent" /> Até {p.max_clients} clientes
                    </li>
                  ) : null}
                </ul>
                <Button
                  asChild
                  className="mt-6 w-full"
                  variant={featured ? "default" : "secondary"}
                >
                  <Link to="/auth" search={{ modo: "cadastro" }}>Começar com {p.name}</Link>
                </Button>
              </div>
            );
          })}
        </div>
      </section>

      {/* Afiliados */}
      <section id="afiliados" className="border-y bg-muted/40">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-20 md:grid-cols-2">
          <div>
            <Target className="size-7 text-primary" />
            <h2 className="mt-4 text-3xl font-bold tracking-tight md:text-4xl">
              Programa de afiliados
            </h2>
            <p className="mt-3 text-muted-foreground">
              Indique novos representantes com o seu código exclusivo e acompanhe o crescimento da
              sua rede. O painel de cliques, conversões e saques está previsto para a Fase 2 —
              nenhuma comissão é liberada sem pagamento confirmado.
            </p>
            <Button asChild className="mt-6">
              <Link to="/auth" search={{ modo: "cadastro" }}>
                Quero ser afiliado <ArrowRight className="ml-1 size-4" />
              </Link>
            </Button>
          </div>
          <div className="rounded-2xl border bg-card p-6 shadow-card">
            <p className="text-sm text-muted-foreground">
              Seu código de indicação é gerado automaticamente no cadastro.
            </p>
            <div className="mt-4 rounded-xl bg-foreground px-5 py-4 text-center font-mono text-xl tracking-[0.3em] text-background">
              MTW-XXXX
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="mx-auto max-w-3xl px-4 py-20">
        <h2 className="text-3xl font-bold tracking-tight md:text-4xl">Perguntas frequentes</h2>
        <Accordion type="single" collapsible className="mt-8">
          {FAQ.map((f) => (
            <AccordionItem
              key={f.q}
              value={f.q}
              className="mb-3 rounded-2xl border bg-card px-5 shadow-card"
            >
              <AccordionTrigger className="text-left">{f.q}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>

      {/* CTA */}
      <section className="bg-foreground text-background">
        <div className="mx-auto max-w-6xl px-4 py-20">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">
            Comece a construir sua agência digital hoje
          </h2>
          <p className="mt-3 text-background/70">
            Cadastre-se gratuitamente, explore a plataforma e ative seu plano com a administração.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <Button asChild>
              <Link to="/auth" search={{ modo: "cadastro" }}>Criar minha conta</Link>
            </Button>
            <Link to="/auth" search={{ modo: "login" }} className="text-sm hover:underline">
              Entrar na plataforma
            </Link>
          </div>
        </div>
      </section>

      <footer className="border-t">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 py-8 text-sm text-muted-foreground md:flex-row">
          <Logo />
          <p>© 2026 Agência MT Web — Sua agência digital. Seu negócio. Seu crescimento.</p>
        </div>
      </footer>
    </div>
  );
}
