import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Rocket } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/redefinir-senha")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Criar nova senha — Agência MT Web" },
      {
        name: "description",
        content: "Defina uma nova senha de acesso à plataforma da Agência MT Web.",
      },
      { property: "og:title", content: "Criar nova senha — Agência MT Web" },
      {
        property: "og:description",
        content: "Recupere o acesso à sua conta da Agência MT Web.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: RedefinirSenha,
});

function RedefinirSenha() {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      if (session) setReady(true);
    });
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) setReady(true);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Senha atualizada com sucesso!");
    navigate({ to: "/painel" });
  }

  return (
    <div className="grid min-h-screen place-items-center bg-soft-gradient px-4 py-10">
      <div className="w-full max-w-md">
        <Link to="/" className="mb-6 flex items-center justify-center gap-2">
          <div className="grid size-9 place-items-center rounded-xl bg-hero-gradient text-primary-foreground">
            <Rocket className="size-5" />
          </div>
          <span className="font-bold">Agência MT Web</span>
        </Link>
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>Criar nova senha</CardTitle>
          </CardHeader>
          <CardContent>
            {ready ? (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="nova">Nova senha</Label>
                  <Input
                    id="nova"
                    type="password"
                    required
                    minLength={8}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Use pelo menos 8 caracteres, com letras, números e símbolos.
                  </p>
                </div>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? "Salvando..." : "Salvar nova senha"}
                </Button>
              </form>
            ) : (
              <div className="space-y-3 text-sm text-muted-foreground">
                <p>
                  Abra esta página pelo link enviado para o seu e-mail para poder criar uma nova
                  senha.
                </p>
                <Button variant="outline" className="w-full" asChild>
                  <Link to="/auth">Voltar para o login</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
