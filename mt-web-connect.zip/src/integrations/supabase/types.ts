export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      clients: {
        Row: {
          address: string | null
          city: string | null
          closed_amount: number | null
          closed_at: string | null
          closed_service: string | null
          cnpj: string | null
          company_name: string
          contact_name: string | null
          created_at: string
          digital_presence: string | null
          email: string | null
          facebook: string | null
          found_at: string | null
          id: string
          instagram: string | null
          next_action_at: string | null
          next_action_note: string | null
          notes: string | null
          owner_id: string
          phone: string | null
          place_id: string | null
          postal_code: string | null
          segment: string | null
          social: string | null
          source: string | null
          stage: string
          state: string | null
          updated_at: string
          website: string | null
        }
        Insert: {
          address?: string | null
          city?: string | null
          closed_amount?: number | null
          closed_at?: string | null
          closed_service?: string | null
          cnpj?: string | null
          company_name: string
          contact_name?: string | null
          created_at?: string
          digital_presence?: string | null
          email?: string | null
          facebook?: string | null
          found_at?: string | null
          id?: string
          instagram?: string | null
          next_action_at?: string | null
          next_action_note?: string | null
          notes?: string | null
          owner_id: string
          phone?: string | null
          place_id?: string | null
          postal_code?: string | null
          segment?: string | null
          social?: string | null
          source?: string | null
          stage?: string
          state?: string | null
          updated_at?: string
          website?: string | null
        }
        Update: {
          address?: string | null
          city?: string | null
          closed_amount?: number | null
          closed_at?: string | null
          closed_service?: string | null
          cnpj?: string | null
          company_name?: string
          contact_name?: string | null
          created_at?: string
          digital_presence?: string | null
          email?: string | null
          facebook?: string | null
          found_at?: string | null
          id?: string
          instagram?: string | null
          next_action_at?: string | null
          next_action_note?: string | null
          notes?: string | null
          owner_id?: string
          phone?: string | null
          place_id?: string | null
          postal_code?: string | null
          segment?: string | null
          social?: string | null
          source?: string | null
          stage?: string
          state?: string | null
          updated_at?: string
          website?: string | null
        }
        Relationships: []
      }
      financial_transactions: {
        Row: {
          amount: number
          category: string | null
          client_id: string | null
          created_at: string
          description: string
          entry_date: string
          id: string
          kind: string
          notes: string | null
          owner_id: string
          project_id: string | null
          status: string
        }
        Insert: {
          amount?: number
          category?: string | null
          client_id?: string | null
          created_at?: string
          description: string
          entry_date?: string
          id?: string
          kind?: string
          notes?: string | null
          owner_id: string
          project_id?: string | null
          status?: string
        }
        Update: {
          amount?: number
          category?: string | null
          client_id?: string | null
          created_at?: string
          description?: string
          entry_date?: string
          id?: string
          kind?: string
          notes?: string | null
          owner_id?: string
          project_id?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "financial_transactions_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "financial_transactions_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_activities: {
        Row: {
          channel: string | null
          client_id: string
          created_at: string
          description: string
          done: boolean
          due_date: string | null
          id: string
          interaction_type: string | null
          kind: string
          next_step: string | null
          owner_id: string
        }
        Insert: {
          channel?: string | null
          client_id: string
          created_at?: string
          description: string
          done?: boolean
          due_date?: string | null
          id?: string
          interaction_type?: string | null
          kind?: string
          next_step?: string | null
          owner_id: string
        }
        Update: {
          channel?: string | null
          client_id?: string
          created_at?: string
          description?: string
          done?: boolean
          due_date?: string | null
          id?: string
          interaction_type?: string | null
          kind?: string
          next_step?: string | null
          owner_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "lead_activities_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          city: string | null
          created_at: string
          full_name: string | null
          id: string
          phone: string | null
          state: string | null
          updated_at: string
        }
        Insert: {
          city?: string | null
          created_at?: string
          full_name?: string | null
          id: string
          phone?: string | null
          state?: string | null
          updated_at?: string
        }
        Update: {
          city?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          phone?: string | null
          state?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      project_tasks: {
        Row: {
          created_at: string
          done: boolean
          id: string
          owner_id: string
          project_id: string
          title: string
        }
        Insert: {
          created_at?: string
          done?: boolean
          id?: string
          owner_id: string
          project_id: string
          title: string
        }
        Update: {
          created_at?: string
          done?: boolean
          id?: string
          owner_id?: string
          project_id?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "project_tasks_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      projects: {
        Row: {
          amount: number
          client_id: string | null
          created_at: string
          due_date: string | null
          id: string
          name: string
          notes: string | null
          owner_id: string
          service_name: string | null
          start_date: string | null
          status: string
          updated_at: string
        }
        Insert: {
          amount?: number
          client_id?: string | null
          created_at?: string
          due_date?: string | null
          id?: string
          name: string
          notes?: string | null
          owner_id: string
          service_name?: string | null
          start_date?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          client_id?: string | null
          created_at?: string
          due_date?: string | null
          id?: string
          name?: string
          notes?: string | null
          owner_id?: string
          service_name?: string | null
          start_date?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "projects_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      proposal_items: {
        Row: {
          created_at: string
          description: string
          id: string
          owner_id: string
          proposal_id: string
          quantity: number
          service_id: string | null
          unit_price: number
        }
        Insert: {
          created_at?: string
          description: string
          id?: string
          owner_id: string
          proposal_id: string
          quantity?: number
          service_id?: string | null
          unit_price?: number
        }
        Update: {
          created_at?: string
          description?: string
          id?: string
          owner_id?: string
          proposal_id?: string
          quantity?: number
          service_id?: string | null
          unit_price?: number
        }
        Relationships: [
          {
            foreignKeyName: "proposal_items_proposal_id_fkey"
            columns: ["proposal_id"]
            isOneToOne: false
            referencedRelation: "proposals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "proposal_items_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      proposals: {
        Row: {
          client_id: string | null
          created_at: string
          discount: number
          id: string
          notes: string | null
          owner_id: string
          payment_terms: string | null
          status: string
          title: string
          total: number
          updated_at: string
          valid_until: string | null
        }
        Insert: {
          client_id?: string | null
          created_at?: string
          discount?: number
          id?: string
          notes?: string | null
          owner_id: string
          payment_terms?: string | null
          status?: string
          title: string
          total?: number
          updated_at?: string
          valid_until?: string | null
        }
        Update: {
          client_id?: string | null
          created_at?: string
          discount?: number
          id?: string
          notes?: string | null
          owner_id?: string
          payment_terms?: string | null
          status?: string
          title?: string
          total?: number
          updated_at?: string
          valid_until?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "proposals_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      prospect_searches: {
        Row: {
          city: string | null
          created_at: string
          id: string
          keyword: string | null
          owner_id: string
          requested: number
          results_count: number
          segment: string | null
          source: string
          state: string | null
        }
        Insert: {
          city?: string | null
          created_at?: string
          id?: string
          keyword?: string | null
          owner_id: string
          requested?: number
          results_count?: number
          segment?: string | null
          source?: string
          state?: string | null
        }
        Update: {
          city?: string | null
          created_at?: string
          id?: string
          keyword?: string | null
          owner_id?: string
          requested?: number
          results_count?: number
          segment?: string | null
          source?: string
          state?: string | null
        }
        Relationships: []
      }
      services: {
        Row: {
          active: boolean
          category: string | null
          commission_percent: number
          created_at: string
          description: string | null
          estimated_days: number
          id: string
          name: string
          suggested_price: number
          updated_at: string
        }
        Insert: {
          active?: boolean
          category?: string | null
          commission_percent?: number
          created_at?: string
          description?: string | null
          estimated_days?: number
          id?: string
          name: string
          suggested_price?: number
          updated_at?: string
        }
        Update: {
          active?: boolean
          category?: string | null
          commission_percent?: number
          created_at?: string
          description?: string | null
          estimated_days?: number
          id?: string
          name?: string
          suggested_price?: number
          updated_at?: string
        }
        Relationships: []
      }
      subscription_plans: {
        Row: {
          active: boolean
          created_at: string
          description: string | null
          features: string[]
          id: string
          max_clients: number
          max_contents: number
          max_projects: number
          name: string
          price_monthly: number
          prospecting_results_limit: number
          prospecting_search_limit: number
          updated_at: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          description?: string | null
          features?: string[]
          id?: string
          max_clients?: number
          max_contents?: number
          max_projects?: number
          name: string
          price_monthly?: number
          prospecting_results_limit?: number
          prospecting_search_limit?: number
          updated_at?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          description?: string | null
          features?: string[]
          id?: string
          max_clients?: number
          max_contents?: number
          max_projects?: number
          name?: string
          price_monthly?: number
          prospecting_results_limit?: number
          prospecting_search_limit?: number
          updated_at?: string
        }
        Relationships: []
      }
      subscriptions: {
        Row: {
          created_at: string
          current_period_end: string | null
          id: string
          notes: string | null
          plan_id: string | null
          started_at: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          current_period_end?: string | null
          id?: string
          notes?: string | null
          plan_id?: string | null
          started_at?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          current_period_end?: string | null
          id?: string
          notes?: string | null
          plan_id?: string | null
          started_at?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "representante" | "afiliado"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "representante", "afiliado"],
    },
  },
} as const
