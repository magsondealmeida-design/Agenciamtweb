import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const searchSchema = z.object({
  city: z.string().trim().min(2).max(100),
  state: z.string().trim().min(2).max(2),
  segment: z.string().trim().min(2).max(100),
  keyword: z.string().trim().max(100).optional().default(""),
  requested: z.number().int().min(1).max(20),
});

type GooglePlace = {
  id?: string;
  displayName?: { text?: string };
  primaryTypeDisplayName?: { text?: string };
  formattedAddress?: string;
  addressComponents?: Array<{ longText?: string; shortText?: string; types?: string[] }>;
  nationalPhoneNumber?: string;
  websiteUri?: string;
  googleMapsUri?: string;
};

export type RadarCompany = {
  placeId: string;
  name: string;
  category: string | null;
  phone: string | null;
  email: null;
  address: string | null;
  city: string | null;
  state: string | null;
  postalCode: string | null;
  website: string | null;
  instagram: null;
  facebook: null;
  googleMapsUrl: string | null;
  source: "Google Places";
  searchedAt: string;
};

const componentValue = (place: GooglePlace, type: string, short = false) => {
  const component = place.addressComponents?.find((item) => item.types?.includes(type));
  return (short ? component?.shortText : component?.longText) ?? null;
};

export const searchProspects = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => searchSchema.parse(input))
  .handler(async ({ data, context }) => {
    const monthStart = new Date();
    monthStart.setUTCDate(1);
    monthStart.setUTCHours(0, 0, 0, 0);

    const [{ data: subscription }, { count: used }] = await Promise.all([
      context.supabase
        .from("subscriptions")
        .select("status, subscription_plans(prospecting_search_limit, prospecting_results_limit)")
        .eq("user_id", context.userId)
        .eq("status", "ativa")
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle(),
      context.supabase
        .from("prospect_searches")
        .select("id", { count: "exact", head: true })
        .eq("owner_id", context.userId)
        .gte("created_at", monthStart.toISOString()),
    ]);

    const plan = subscription?.subscription_plans as
      | { prospecting_search_limit?: number; prospecting_results_limit?: number }
      | null
      | undefined;
    // Durante o desenvolvimento, pesquisas liberadas mesmo sem assinatura ativa.
    const searchLimit = plan?.prospecting_search_limit ?? 100000;
    const resultLimit = Math.min(plan?.prospecting_results_limit ?? 20, 20);
    if ((used ?? 0) >= searchLimit) {
      throw new Error(`Seu limite mensal de ${searchLimit} pesquisas foi atingido.`);
    }

    const requested = Math.min(data.requested, resultLimit);
    const lovableKey = process.env["LOVABLE_API_KEY"];
    const mapsKey = process.env["GOOGLE_MAPS_API_KEY"];
    if (!lovableKey || !mapsKey) {
      throw new Error("A fonte de pesquisa ainda não está configurada.");
    }

    const textQuery = [data.keyword, data.segment, "em", data.city, data.state, "Brasil"]
      .filter(Boolean)
      .join(" ");
    const response = await fetch(
      "https://connector-gateway.lovable.dev/google_maps/places/v1/places:searchText",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${lovableKey}`,
          "X-Connection-Api-Key": mapsKey,
          "Content-Type": "application/json",
          "X-Goog-FieldMask":
            "places.id,places.displayName,places.primaryTypeDisplayName,places.formattedAddress,places.addressComponents,places.nationalPhoneNumber,places.websiteUri,places.googleMapsUri",
        },
        body: JSON.stringify({ textQuery, pageSize: requested, languageCode: "pt-BR", regionCode: "BR" }),
      },
    );

    if (!response.ok) {
      const body = await response.text();
      console.error(`Google Places falhou [${response.status}]: ${body}`);
      if (response.status === 403) {
        throw new Error("A pesquisa foi recusada pela configuração do Google Maps. Verifique as APIs permitidas na conexão.");
      }
      throw new Error("Não foi possível consultar a fonte agora. Tente novamente mais tarde.");
    }

    const payload = (await response.json()) as { places?: GooglePlace[] };
    const searchedAt = new Date().toISOString();
    const companies: RadarCompany[] = (Array.isArray(payload.places) ? payload.places : [])
      .filter((place) => place.id && place.displayName?.text)
      .map((place) => ({
        placeId: place.id ?? "",
        name: place.displayName?.text ?? "Empresa sem nome",
        category: place.primaryTypeDisplayName?.text ?? null,
        phone: place.nationalPhoneNumber ?? null,
        email: null,
        address: place.formattedAddress ?? null,
        city:
          componentValue(place, "administrative_area_level_2") ??
          componentValue(place, "locality") ??
          data.city,
        state: componentValue(place, "administrative_area_level_1", true) ?? data.state,
        postalCode: componentValue(place, "postal_code"),
        website: place.websiteUri ?? null,
        instagram: null,
        facebook: null,
        googleMapsUrl: place.googleMapsUri ?? null,
        source: "Google Places",
        searchedAt,
      }));

    const { error: logError } = await context.supabase.from("prospect_searches").insert({
      owner_id: context.userId,
      city: data.city,
      state: data.state.toUpperCase(),
      segment: data.segment,
      keyword: data.keyword || null,
      requested,
      results_count: companies.length,
      source: "google_places",
    });
    if (logError) console.error("Falha ao registrar consumo do Radar", logError.message);

    return {
      companies,
      usage: { used: (used ?? 0) + 1, limit: searchLimit, resultLimit },
    };
  });