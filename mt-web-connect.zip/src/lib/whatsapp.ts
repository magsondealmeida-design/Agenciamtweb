/** Dados mínimos necessários para montar uma abordagem (compatível com RadarCompany). */
export type ApproachTarget = {
  name: string;
  category?: string | null;
  city?: string | null;
  state?: string | null;
  website?: string | null;
  instagram?: string | null;
  facebook?: string | null;
};

export const APPROACH_TEMPLATES = [
  { id: "geral", label: "1. Primeiro contato — geral" },
  { id: "sem_site", label: "2. Empresa sem site identificado" },
  { id: "parcial", label: "3. Presença digital parcial" },
  { id: "conteudo", label: "4. Criação de conteúdo" },
  { id: "redes", label: "5. Redes sociais" },
  { id: "local", label: "6. Presença digital para empresa local" },
] as const;

export type ApproachTemplateId = (typeof APPROACH_TEMPLATES)[number]["id"];

export const RADAR_STATUSES = [
  "Novo",
  "Contato iniciado",
  "Respondeu",
  "Interessado",
  "Sem resposta",
  "Não interessado",
  "Proposta enviada",
  "Cliente",
] as const;

export type RadarStatus = (typeof RADAR_STATUSES)[number];

export function suggestTemplate(company: ApproachTarget): ApproachTemplateId {
  if (!company.website) return "sem_site";
  if (!company.instagram && !company.facebook) return "parcial";
  return "geral";
}

/** Formata para o padrão internacional do WhatsApp (Brasil +55). */
export function toWhatsappNumber(phone: string | null): string | null {
  if (!phone) return null;
  let digits = phone.replace(/\D/g, "");
  if (digits.startsWith("0")) digits = digits.replace(/^0+/, "");
  if (!digits.startsWith("55")) digits = `55${digits}`;
  // 55 + DDD (2) + 8 ou 9 dígitos
  if (digits.length < 12 || digits.length > 13) return null;
  return digits;
}

type Vars = { representante: string; empresa: string; segmento: string; cidade: string; estado: string };

function varsOf(company: ApproachTarget, representante: string, fallbackSegment: string): Vars {
  return {
    representante: representante.trim() || "um representante",
    empresa: company.name,
    segmento: (company.category ?? fallbackSegment ?? "").trim(),
    cidade: company.city ?? "",
    estado: company.state ?? "",
  };
}

function place(v: Vars) {
  const local = [v.cidade, v.estado].filter(Boolean).join(" - ");
  return local ? ` em ${local}` : "";
}

function origem(v: Vars) {
  const seg = v.segmento ? ` de ${v.segmento}` : "";
  return `Encontrei a ${v.empresa} durante uma pesquisa de empresas${seg}${place(v)}.`;
}

export function buildApproachMessage(
  company: ApproachTarget,
  template: ApproachTemplateId,
  representante: string,
  fallbackSegment: string,
): string {
  const v = varsOf(company, representante, fallbackSegment);
  const abertura = `Olá, tudo bem? 👋\n\nMeu nome é ${v.representante}, sou da Agência MT Web.\n\n${origem(v)}`;

  switch (template) {
    case "sem_site":
      return `${abertura}\n\nDurante a pesquisa, não consegui identificar um site da empresa nas fontes que consultei.\n\nNós ajudamos empresas a criar uma presença profissional na internet.\n\nPosso te mostrar uma ideia de como poderia ficar a presença online da ${v.empresa}, sem compromisso?`;
    case "parcial":
      return `${abertura}\n\nTrabalhamos ajudando empresas a melhorar sua presença digital, incluindo sites, conteúdo e redes sociais.\n\nPosso te mostrar uma ideia rápida sobre como poderíamos trabalhar a presença digital da ${v.empresa}?`;
    case "conteudo":
      return `${abertura}\n\nTrabalhamos com criação de conteúdo e estratégias de presença digital para empresas.\n\nPosso te mostrar uma ideia de conteúdo que poderíamos desenvolver para a empresa?`;
    case "redes":
      return `${abertura}\n\nTrabalhamos com redes sociais para empresas: planejamento, publicações e acompanhamento.\n\nPosso te mostrar uma ideia de como poderíamos cuidar das redes sociais da ${v.empresa}?`;
    case "local":
      return `${abertura}\n\nTrabalhamos com presença digital para empresas da região, ajudando a serem encontradas por quem procura na internet.\n\nPosso te mostrar rapidamente uma ideia que poderia ajudar a ${v.empresa}?`;
    default:
      return `${abertura}\n\n${
        v.segmento ? `Vi que vocês atuam com ${v.segmento} e estou` : "Estou"
      } entrando em contato porque trabalhamos com presença digital para empresas da região.\n\nPosso te mostrar rapidamente uma ideia que poderia ajudar a empresa de vocês na internet?\n\nSe fizer sentido, te explico por aqui mesmo. 👍`;
  }
}

export function whatsappUrl(number: string, message: string) {
  return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}
