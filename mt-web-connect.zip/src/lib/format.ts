export const brl = (value: number | string | null | undefined) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(Number(value ?? 0));

export const dateBR = (value: string | null | undefined) =>
  value ? new Date(value + (value.length === 10 ? "T00:00:00" : "")).toLocaleDateString("pt-BR") : "—";

export const STAGES = [
  { value: "novo_lead", label: "Novo lead" },
  { value: "contato_iniciado", label: "Contato iniciado" },
  { value: "em_conversa", label: "Em conversa" },
  { value: "contato", label: "Contato realizado" },
  { value: "interessado", label: "Interessado" },
  { value: "reuniao", label: "Reunião agendada" },
  { value: "proposta", label: "Proposta enviada" },
  { value: "negociacao", label: "Negociação" },
  { value: "ganho", label: "Cliente ganho (fechado)" },
  { value: "perdido", label: "Cliente perdido" },
];

export const CHANNELS = [
  { value: "whatsapp", label: "WhatsApp" },
  { value: "telefone", label: "Telefone" },
  { value: "email", label: "E-mail" },
  { value: "reuniao", label: "Reunião" },
  { value: "instagram", label: "Instagram" },
  { value: "facebook", label: "Facebook" },
  { value: "outro", label: "Outro" },
];

export const INTERACTION_TYPES = [
  { value: "primeiro_contato", label: "Primeiro contato" },
  { value: "retorno", label: "Retorno" },
  { value: "respondeu", label: "Cliente respondeu" },
  { value: "apresentacao", label: "Apresentação" },
  { value: "duvida", label: "Dúvida" },
  { value: "negociacao", label: "Negociação" },
  { value: "proposta_enviada", label: "Proposta enviada" },
  { value: "follow_up", label: "Follow-up" },
  { value: "fechamento", label: "Fechamento" },
  { value: "sem_interesse", label: "Sem interesse" },
  { value: "outro", label: "Outro" },
];

export const dateTimeBR = (value: string | null | undefined) =>
  value ? new Date(value).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }) : "—";

export const PROJECT_STATUS = [
  { value: "aguardando", label: "Aguardando início" },
  { value: "andamento", label: "Em andamento" },
  { value: "cliente", label: "Aguardando cliente" },
  { value: "revisao", label: "Em revisão" },
  { value: "concluido", label: "Concluído" },
  { value: "cancelado", label: "Cancelado" },
];

export const PROPOSAL_STATUS = [
  { value: "rascunho", label: "Rascunho" },
  { value: "enviada", label: "Enviada" },
  { value: "aceita", label: "Aceita" },
  { value: "recusada", label: "Recusada" },
  { value: "expirada", label: "Expirada" },
];

export const labelOf = (list: { value: string; label: string }[], value: string) =>
  list.find((i) => i.value === value)?.label ?? value;
