ALTER TABLE public.lead_activities
  ADD COLUMN IF NOT EXISTS channel text,
  ADD COLUMN IF NOT EXISTS interaction_type text,
  ADD COLUMN IF NOT EXISTS next_step text;

ALTER TABLE public.clients
  ADD COLUMN IF NOT EXISTS next_action_at timestamp with time zone,
  ADD COLUMN IF NOT EXISTS next_action_note text,
  ADD COLUMN IF NOT EXISTS closed_at date,
  ADD COLUMN IF NOT EXISTS closed_service text,
  ADD COLUMN IF NOT EXISTS closed_amount numeric;

CREATE INDEX IF NOT EXISTS clients_next_action_idx ON public.clients (owner_id, next_action_at);