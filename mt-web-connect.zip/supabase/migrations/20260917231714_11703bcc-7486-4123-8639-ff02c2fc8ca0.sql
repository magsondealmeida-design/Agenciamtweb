CREATE TABLE public.prospect_searches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  city text,
  state text,
  segment text,
  keyword text,
  requested integer NOT NULL DEFAULT 10,
  results_count integer NOT NULL DEFAULT 0,
  source text NOT NULL DEFAULT 'demo',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.prospect_searches TO authenticated;
GRANT ALL ON public.prospect_searches TO service_role;
ALTER TABLE public.prospect_searches ENABLE ROW LEVEL SECURITY;
CREATE POLICY prospect_searches_owner_all ON public.prospect_searches FOR ALL TO authenticated
  USING (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));

ALTER TABLE public.clients
  ADD COLUMN IF NOT EXISTS place_id text,
  ADD COLUMN IF NOT EXISTS instagram text,
  ADD COLUMN IF NOT EXISTS facebook text,
  ADD COLUMN IF NOT EXISTS address text,
  ADD COLUMN IF NOT EXISTS postal_code text,
  ADD COLUMN IF NOT EXISTS digital_presence text,
  ADD COLUMN IF NOT EXISTS found_at timestamptz;

CREATE UNIQUE INDEX IF NOT EXISTS clients_owner_place_unique
  ON public.clients (owner_id, place_id) WHERE place_id IS NOT NULL;

ALTER TABLE public.subscription_plans
  ADD COLUMN IF NOT EXISTS prospecting_search_limit integer NOT NULL DEFAULT 10,
  ADD COLUMN IF NOT EXISTS prospecting_results_limit integer NOT NULL DEFAULT 20;